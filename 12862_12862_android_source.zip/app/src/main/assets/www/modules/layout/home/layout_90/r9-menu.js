function openNav() {
    document.getElementById("myNav").style.width = "100%";
    document.getElementById("main").style.marginLeft = "100%";
}

function closeNav() {
    document.getElementById("myNav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
}
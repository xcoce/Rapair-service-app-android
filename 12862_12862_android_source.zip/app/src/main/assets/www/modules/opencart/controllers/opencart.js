App.config(function($stateProvider) {
    $stateProvider.state('cart_view', {
        url: BASE_PATH + "/opencart/mobile_view/index/value_id/:value_id",
        controller: 'opencartController',
        cache: false,
        templateUrl: "modules/opencart/templates/l1/view.html"
    }).state('product-list-by-manufacturer', {
        url: BASE_PATH + "/opencart/mobile_view/index/value_id/:value_id/manufacturer_id/:manufacturer_id",
        controller: 'manufacturerproductsController',
        cache: false,
        templateUrl: "modules/opencart/templates/l1/brand-products-list.html"
    }).state('category-product-list', {
        url: BASE_PATH + "/opencart/mobile_view/index/value_id/:value_id/category_id/:category_id/sub_category_id/:sub_category_id",
        controller: 'categoryController',
        templateUrl: "modules/opencart/templates/l1/category_product_list.html"
    }).state('product-details', {
        url: BASE_PATH + "/opencart/mobile_view/index/value_id/:value_id/product_id/:product_id",
        controller: 'productdetailController',
         cache: false,
        templateUrl: "modules/opencart/templates/l1/products_details.html"
    }).state('opencart-customer-account', {
        url: BASE_PATH + "/opencart/mobile_view/index/value_id/:value_id/customer/:customer",
        controller: 'OpenCartUserController',
        templateUrl: "modules/opencart/templates/l1/opencart-customer-account.html"
    }).state('customer-registration', {
        url: BASE_PATH + "/opencart/mobile_view/index/value_id/:value_id/registration/:registration",
        controller: 'CustomerRegistrationController',
        cache: false,
        templateUrl: "modules/opencart/templates/l1/signup-customer.html"
    }).state('opencart-user-login', {
        url: BASE_PATH + "/opencart/mobile_view/index/value_id/:value_id/login/:login",
        controller: 'opencartUserloginController',
        cache: false,
        templateUrl: "modules/opencart/templates/l1/customer_login.html"
    }).state('cart-item-list', {
        url: BASE_PATH + "/opencart/mobile_view/index/value_id/:value_id/cart/:cart",
        controller: 'CartItemListController',
        cache: false,
        templateUrl: "modules/opencart/templates/l1/cart-item-list.html"
    }).state('checkout-address', {
        url: BASE_PATH + "/opencart/mobile_view/index/value_id/:value_id/order/:order",
        controller: 'CheckoutAddressController',
        templateUrl: "modules/opencart/templates/l1/checkout-address.html"
    }).state('delivery-methods', {
        url: BASE_PATH + "/opencart/mobile_view/index/value_id/:value_id/delivery_methods/:delivery_methods",
        controller: 'DeliveryMethodsController',
        cache: false,
        templateUrl: "modules/opencart/templates/l1/delivery_methods.html"
    }).state('payment-methods', {
        url: BASE_PATH + "/opencart/mobile_view/index/value_id/:value_id/payment/:payment",
        controller: 'PaymentMethodsController',
        cache: false,
        templateUrl: "modules/opencart/templates/l1/payment-methods.html"
    }).state('order-processed', {
        url: BASE_PATH + "/opencart/mobile_view/index/value_id/:value_id/process/:process",
        controller: 'OrderProcessedController',
        templateUrl: "modules/opencart/templates/l1/order-success-message.html"
    }).state('paypal-processed', {
        url: BASE_PATH + "/opencart/mobile_view/index/value_id/:value_id/paypaloption/:paypaloption",
        controller: 'OrderProcessedWithPaypalController',
        templateUrl: "modules/opencart/templates/l1/paypal-process-option.html"
    }).state('search-page', {
        url: BASE_PATH + "/opencart/mobile_view/index/value_id/:value_id/search/:search",
        controller: 'SearchProductsController',
        templateUrl: "modules/opencart/templates/l1/search-product-page.html"
    }).state('customer-wishlist', {
        url: BASE_PATH + "/opencart/mobile_view/index/value_id/:value_id/wishlist/:wishlist",
        controller: 'CustomerwishlistController',
        cache: false,
        templateUrl: "modules/opencart/templates/l1/customer-wishlist.html"
    }).state('deposit-or-transfer', {
        url: BASE_PATH + "/opencart/mobile_view/index/value_id/:value_id/deposit_or_transfer/:deposit_or_transfer",
        controller: 'DepositOrTransferController',
        cache: false,
        templateUrl: "modules/opencart/templates/l1/deposit-or-transfer.html"
    }).state('order-multibanco-processed', {
        url: BASE_PATH + "/opencart/mobile_view/index/value_id/:value_id/multibanco/:multibanco",
        controller: 'MultibancoController',
        cache: false,
        templateUrl: "modules/opencart/templates/l1/multibanco_details.html"
    }).state('order-total-processed', {
        url: BASE_PATH + "/opencart/mobile_view/index/value_id/:value_id/order_total/:order_total",
        controller: 'OrdertTotalController',
        cache: false,
        templateUrl: "modules/opencart/templates/l1/details_before_confirmation.html"
    });
    
    $stateProvider.state('opencart-sales-confirmation-payment', {
        url: BASE_PATH+"/opencart/mobile_view/index/value_id/:value_id/confirm/:confirm/token/:token/payerId/:payerId",
        controller: 'OpencartSalesConfirmationConfirmPaymentController',
        templateUrl: "modules/opencart/templates/l1/confirmation.html",
        cache:false
    });
    $stateProvider.state('opencart-sales-confirmation-cancel', {
        url: BASE_PATH+"/opencart/mobile_view/index/value_id/:value_id/cancel/:cancel",
        controller: 'OpencartSalesConfirmationCancelController',
        templateUrl: "modules/opencart/templates/l1/view.html",
        cache:false
    });
    //This is for web view paypal
    $stateProvider.state('opencart-sales-web-paypal-confirmation-payment', {
        url: BASE_PATH+"/opencart/mobile_view/index/value_id/:value_id/confirm/:confirm",
        controller: 'OpencartWebSalesConfirmationCancelController',
        templateUrl: "modules/opencart/templates/l1/order-success-message.html",
        cache:false
    });
    $stateProvider.state('opencart-sales-stripe', {
        url: BASE_PATH+"/opencart/mobile_view/index/value_id/:value_id/stripe/:stripe",
        controller: 'OpencartSalesStripeViewController',
        templateUrl: "modules/opencart/templates/l1/stripe.html",
        cache:false
    });

}).controller('opencartController', function($ionicModal,$ionicScrollDelegate,$translate, $ionicLoading ,Customer,Authorization, $timeout,AUTH_EVENTS,Dialog, $scope,$ionicPopup,$ionicPopover,$interval, $rootScope,OpenCart,$state, $stateParams, $ionicSlideBoxDelegate, SafePopups) {
    $scope.contDirModal = {};
    $scope.brand_slider = false;
    $scope.is_set_search = 0;
    $scope.is_loading = true;
    $scope.value_id = OpenCart.value_id = $stateParams.value_id;
    $scope.is_logged_in = Customer.isLoggedIn();
    /*get store  details*/
    OpenCart.getstoredetails().success(function(store_data) {
        $scope.homepage_dynamic_border_color = store_data.homepage_dynamic_border_color;
       if(store_data.store.success){
            $scope.page_title = $translate.instant(store_data.store.data.store_name);
            OpenCart.store_name = store_data.store.data.store_name;
        }else{
            $scope.page_title = $translate.instant("Open Cart");
        }
    });
        OpenCart.getappapidetails().success(function(appapiresponse){
            $scope.app_header_image = appapiresponse.app_header_image;
            $scope.app_name = appapiresponse.app_name;
            $scope.footer_payment_image = appapiresponse.footer_payment_image;
        });
    /*function which is call on login button hit*/
    $scope.login = function() {
        if(OpenCart.opencart_local_item('opencart_user_session_id')){
            OpenCart.getapicartdata().success(function(response) {
                if(response.cart_details=='error'){
                    $scope.list_item = 0;
                }else{
                    $scope.list_item = 1;
                    $scope.cart_response_data = response.cart_details.data.products;
                    $scope.cart_response_total = response.cart_details.data.totals;
                    OpenCart.set_opencart_local_item('opencart_counter',response.cart_item_counter);
                }
                $state.go("opencart-customer-account", { value_id: $scope.value_id, customer:1 });
            }).finally(function() {
                $scope.is_loading = false;
            });
        }else{
            $state.go("opencart-user-login",{ value_id: $scope.value_id, login:1});
        }
    };
    $scope.page = 1;//new Array();
    $scope.products_lists = new Array();
    $scope.can_load_older_posts = true;
    $scope.noMoreItemsAvailable = false;
    //load more products
    $scope.loadContent = function() { 
        OpenCart.getallproducts($scope.page).success(function(data) {
            OpenCart.base_url   = data.base_url;
            $scope.base_url     = data.base_url;
            $scope.homepage_dynamic_border_color = data.homepage_dynamic_border_color;
            $scope.tooltip_background_color = data.tooltip_background_color;
            $scope.tooltip_text_color = data.tooltip_text_color;
           /* $scope.COLOR_BORDER_CHILS_3N_2 = '.row.product-list-row > div:nth-child(3n+2)  { border-bottom: 1px solid ' + data.homepage_dynamic_border_color + ' !important; }';
            $scope.COLOR_BORDER_NTH_CHILD = '.row.product-list-row > div:nth-child(odd)  {  border-right: 1px solid ' + data.homepage_dynamic_border_color + ' !important; }';
            $scope.COLOR_BORDER_NTH_EVEN = '.col.col-50.product_list:nth-of-type(even)  {  border-left: 1px solid ' + data.homepage_dynamic_border_color + ' !important; }';
            *///$scope.COLOR_BORDER_BOTTOM = '.row.product-list-row > div:nth-child(3n+2)  { background-color: ' + data.homepage_dynamic_border_color + ' !important; }';
            
            if(data.products == null){
                $scope.noMoreItemsAvailable = true;
            }else{
                $scope.items.push({ id: data.products.length});
                $scope.can_load_older_posts = !!data.products.length;
                $scope.products_lists = $scope.products_lists.concat(data.products);
            }
        }).finally(function() {
            $scope.is_loading = false;
        });
    };
    /*get all products list on home page from api*/
    $scope.$on("$ionicView.beforeEnter", function(event, data){
        $scope.loadContent();
        /*get the banner imapge from api*/
        OpenCart.getbannerslider().success(function(slider_data) {
           $scope.slider_lists = slider_data.sliders;
        });
        /*get all categories listapi*/
        $scope.groups = [];
        $scope.myitems = [];
        OpenCart.getcategories().success(function(category_data) {
            $scope.limited_category_list = category_data.limited_category_list;
            $scope.category_list = category_data.category_list;
            //adding expand list
            angular.forEach(category_data.category_list, function(cat_name, key) {
                OpenCart.filters = cat_name.filters.filter_groups;
                angular.forEach( OpenCart.filters, function(f_group, key) {
                    OpenCart.Itm =  $scope.items[key] = {
                            name: f_group.name,
                            id: f_group.filter_group_id
                        };
                    });
                    $scope.groups[key] = {
                        name: cat_name.name,
                        items: OpenCart.Itm,
                        parent_id:cat_name.category_id
                    };
                });
                
        }).finally(function() {
            $scope.is_loading = false;
        });
        $scope.toggleGroup = function(group) {
            if ($scope.isGroupShown(group)) {
                $scope.shownGroup = null;
            } else {
              $scope.shownGroup = group;
            }
        }
        $scope.toggleSubGroup = function(item) {
            if ($scope.isSubGroupShown(item)) {
                $scope.shownChild = null;
            } else {
                $scope.shownChild = item;
            }
        }
        $scope.isGroupShown = function(group) {
            return $scope.shownGroup === group;
        }
        $scope.isSubGroupShown = function(item) {
            return $scope.shownChild === item;
        }
        $('input#searchqueires').keyup( function() {
            if( this.value.length < 1 ){
                $state.go('cart_view', { value_id: $scope.value_id }, { reload: true });
            };
            /* code to run below */
            $scope.is_loading = true;
            var current_page = 1;
            OpenCart.searchqueiresrequest(this.value, current_page).success(function(search_result) {
                if(search_result.search_query_products !='error'){
                    $scope.products_lists = search_result.search_query_products;
                    $scope.is_set_search = 1;
                }else{
                    $scope.is_loading = false;
                    $scope.noMoreSearchItemsAvailable = true;
                }
                
            }).finally(function() {
                $scope.is_loading = false;
            });
        });
        $scope.can_load_older_search_posts = true;
        $scope.noMoreSearchItemsAvailable = false;
        $scope.spage = 1;
        $scope.loadSearchContent = function(current_page) { 
            $scope.is_loading = true;
            var search_key  = $('input#searchqueires').val();
            OpenCart.searchqueiresrequest(search_key, current_page).success(function(search_result) {
                if(search_result.search_query_products =='error'){
                    $scope.noMoreSearchItemsAvailable = true;
                }else{
                    $scope.items.push({ id: search_result.search_query_products.length});
                    $scope.can_load_older_search_posts = !!search_result.search_query_products.length;
                    $scope.products_lists = $scope.products_lists.concat(search_result.search_query_products);
                    $scope.is_set_search = 1;
                }
            }).finally(function() {
                $scope.is_loading = false;
            });
        };
        $scope.loadSearchMore = function() {
            $scope.spage++;
            $scope.is_set_search = 1;
            $scope.loadSearchContent($scope.spage);
            $scope.$broadcast('scroll.infiniteScrollComplete');
        };
        /*expand to sub categories*/
        $scope.subCategories = function(category_id) {
            $ionicLoading.show({content: 'Loading',animation: 'fade-in',showBackdrop: true,maxWidth: 200,showDelay: 0 });
            OpenCart.subcategories(category_id).success(function(sub_category_data) {
                $scope.mitems = sub_category_data.subcategories;
                $scope.is_opencart_global_app = sub_category_data.is_opencart_global_app;
            }).finally(function() {
                $ionicLoading.hide();
            });
          };
        $scope.subSubCategories = function(category_id) {
            $ionicLoading.show({content: 'Loading',animation: 'fade-in',showBackdrop: true,maxWidth: 200,showDelay: 0 });
            OpenCart.subcategories(category_id).success(function(sub_category_data) {
                $scope.sub_sub_categories = sub_category_data.subSubcategories;
            }).finally(function() {
                $ionicLoading.hide();
            });
        };
        $timeout(function() {
            if(OpenCart.opencart_local_item('opencart_user_session_id')){
                OpenCart.getapicartdata().success(function(response) {
                    $scope.is_loading = false;
                    if(response.cart_details.success){
                        $scope.list_item            = 1;
                        $scope.cart_response_data   = response.cart_details.data.products;
                        $scope.cart_response_total  = response.cart_details.data.totals;
                        OpenCart.set_opencart_local_item('opencart_counter',response.cart_item_counter);
                        $scope.total_items =  OpenCart.opencart_local_item('opencart_counter');
                    }else{
                        $scope.list_item = 0;
                    }
                });
            }else{
                //for local session cart items
                if(OpenCart.opencart_local_item('opencart_counter') > 0 ){
                    OpenCart.set_opencart_local_item('opencart_counter', OpenCart.opencart_local_item('opencart_counter'));
                    $scope.total_items = OpenCart.opencart_local_item('opencart_counter');
                }
                
            }
        }, 500);
    });
    $scope.loadMore = function() {
        $scope.page++;
        $scope.loadContent();
        $scope.$broadcast('scroll.infiniteScrollComplete');
    };
    $scope.items = [];
    /*get product details on the basis of product id from api*/
    $scope.productdetails = function(product_id) {
        $state.go("product-details",{ value_id: $scope.value_id, product_id:product_id });
    };
    /*  Category model to popup*/
    $scope.openCategory = function() {
        $ionicModal.fromTemplateUrl('modules/opencart/templates/l1/category-list.html', {
            scope: $scope,
            animation: 'slide-in-up'
        }).then(function(modal) {
            $scope.contDirModal.search = modal;
            $scope.contDirModal.search.show();
            $ionicLoading.hide();
        });
    };
    OpenCart.by_manufacturer_id = 0;
    $scope.getSliderCategory = function(slider_link) {
        $scope.cpage = 1;
        
        var fliter_id = slider_link.split(";category_id=");

        var path_fliter_id = fliter_id[1].split("&amp;product_id=");
        if (path_fliter_id[1] != undefined) {
            var f_id = path_fliter_id[0];
            
            OpenCart.by_manufacturer_id = 0;
        }
         else{
            var fliter_manufacturer_id = slider_link.split(";manufacturer_id=");
            var f_id = fliter_manufacturer_id[1];
            if(f_id != undefined){
                OpenCart.by_manufacturer_id = 1;
            }
        }
        /*There is no link availabe for get ids*/
        /***NOTE***this category id unbale to get the product so i can use for manufature id 
        ***********which in not in in slider link*********/
        if( f_id== 90){
          OpenCart.by_manufacturer_id = 1;
          f_id = 62;
        }
        if( f_id== 9){
          OpenCart.by_manufacturer_id = 1;
          f_id = 17;
        }
        if(f_id != undefined){
          $state.go("category-product-list",{ value_id: $scope.value_id, category_id:f_id, sub_category_id:f_id }); 
        }
    };
    /**
    * Remove all opened Contact Directory modals at once
    */
    $scope.closeModal = function() {
        if(angular.isObject($scope.contDirModal)) {
            for (var i in $scope.contDirModal) {
                if(angular.isObject($scope.contDirModal[i]) && angular.isFunction($scope.contDirModal[i].remove)) {
                    $scope.contDirModal[i].remove();
                }
            }
        }
    }
    /*get category product lists*/
    $scope.getcategoryproducts = function(category_id, category_name,category_url, sub_category_id) {
        $scope.page_title = category_name;
        OpenCart.category_name = category_name;
        OpenCart.category_url = category_url;
        OpenCart.sub_category_id = sub_category_id;
        $scope.closeModal();
        $state.go("category-product-list",{ value_id: $scope.value_id, category_id:category_id,sub_category_id:sub_category_id });
   };
    /*opencart user details*/
    $scope.opencartUser = function() {
        $state.go("opencart-customer-account", { value_id: $scope.value_id, customer:1 });
    }
    /*add function for cart button click and go to item list added into cart */
    $scope.cartItemList = function() {
        if(OpenCart.opencart_local_item('opencart_user_session_id')){
            //get all cart item list 
            OpenCart.getapicartdata().success(function(response) {
                if(response.cart_details.success){
                    $scope.list_item = 1;
                    $scope.cart_response_data = response.cart_details.data.products;
                    $scope.total_items = response.cart_item_counter;
                    $scope.cart_response_total = response.cart_details.data.totals;
                }else{
                   $scope.list_item = 0;
                }
                $state.go("cart-item-list", { value_id: $scope.value_id, cart:1 });
            }).finally(function() {
                $ionicLoading.hide();
                $scope.is_loading = false;
            });
        }else{
            $state.go("cart-item-list", { value_id: $scope.value_id, cart:1 });
        }
    }
    /*function which is redirect to searc page*/
    $scope.gotosearch = function() {
        $state.go("search-page",{ value_id: $scope.value_id, search:1 });
    }
    /**
    * Remove all opened Contact Directory modals at once
    */
    $scope.closeModal = function() {
        if(angular.isObject($scope.contDirModal)) {
            for (var i in $scope.contDirModal) {
                if(angular.isObject($scope.contDirModal[i]) && angular.isFunction($scope.contDirModal[i].remove)) {
                    $scope.contDirModal[i].remove();
                }
            }
        }
    }
    if(OpenCart.opencart_local_item('opencart_counter') > 0){
        $scope.total_items =  OpenCart.opencart_local_item('opencart_counter') ;
        //for local session cart items
        OpenCart.set_opencart_local_item('opencart_counter', $scope.total_items);    
    }
    $scope.addProductTocart = function(request_cart_item) {
        OpenCart.p_quantity = $('#p_count').val();

        if(OpenCart.p_quantity >= 1){
            if(OpenCart.opencart_local_item('opencart_user_session_id') && Customer.isLoggedIn()){
                $ionicLoading.show({content: 'Loading',animation: 'fade-in',showBackdrop: true,maxWidth: 200,showDelay: 0 });
                OpenCart.additemtocart(request_cart_item).success(function(data) {
                    $ionicLoading.hide();
                    if(data.cart_api_response_details.success) {
                        $scope.total_items =  OpenCart.opencart_local_item('opencart_counter');
                        OpenCart.set_opencart_local_item('opencart_counter', $scope.total_items++)
                    }
                    $state.go('cart_view', { value_id: $scope.value_id }, { reload: true });
                }).error(function(data) {
                    if(data && angular.isDefined(data.message)) {
                        Dialog.alert($translate.instant("Error"), data.message, $translate.instant("OK"));
                    }

                }).finally(function() {
                    $scope.is_loading = false;
                    
                });
            }else{
                if(OpenCart.bulk_cart_data == undefined){
                    OpenCart.bulk_cart_data  = [];
                }
                //if not login and click to add to cart then cart data save and after checkout asked user to login
                if(OpenCart.opencart_local_item('opencart_counter') >=   1){
                    $scope.total_items =  OpenCart.opencart_local_item('opencart_counter');
                    $scope.total_items ++;
                    OpenCart.set_opencart_local_item('opencart_counter',  $scope.total_items);
                }else{
                    OpenCart.set_opencart_local_item('opencart_counter', 0);
                    if($scope.total_items > 0){
                        OpenCart.set_opencart_local_item('opencart_counter',  $scope.total_items);
                        OpenCart.set_opencart_local_item('cart_bulk_data',  OpenCart.bulk_cart_data);
                    }else{
                        OpenCart.set_opencart_local_item('opencart_counter', 0)
                        OpenCart.bulk_cart_data  = [];
                    }
                    $scope.total_items =  OpenCart.opencart_local_item('opencart_counter');
                    $scope.total_items ++;
                    OpenCart.set_opencart_local_item('opencart_counter',  $scope.total_items);
                }
                $scope.localcartitem = request_cart_item;
                OpenCart.guestcartitem = $scope.localcartitem;
                var task_details = [];
                OpenCart.bulk_cart_data.push(request_cart_item);
                OpenCart.set_opencart_local_item('cart_bulk_data',  OpenCart.bulk_cart_data);
                /**now the current user add as guest**/
                OpenCart.additemtolocalsessioncart(request_cart_item).success(function(data) {
                    $scope.is_loading = false;
                    $ionicLoading.hide();
                });
            }
        }else{
           $ionicPopup.alert({title: $translate.instant('Error'),template: $translate.instant("Please enter valid quantity of prodect."),buttons: [{ text: $translate.instant("OK") }]});
           
        }
    };
    OpenCart.getallbrands().success(function(brand_data) {
        if(brand_data.brands){
            $scope.all_brand_data = brand_data.brands;
            $scope.list_brands = brand_data.brands;
            $scope.have_brands = 1;
        }else{
            $scope.have_brands = 0;
        }
    }).finally(function() {
        $scope.is_loading = false;
    });
    $scope.productsListByBrands = function(manufacturer_id,brand_name) {
        OpenCart.brand_name = brand_name;
        $state.go("product-list-by-manufacturer",{ value_id: $scope.value_id, manufacturer_id:manufacturer_id });
    };
    $scope.brand_slider = true;
    $timeout(function() {
        var swiper = new Swiper('.swiper-container', {
            pagination: '.swiper-pagination',
            slidesPerView: 3,
            autoplay: 2500,
            paginationClickable: true,
            spaceBetween: 30
            

        });
    }, 3000);
    $timeout(function() {
        var swiper = new Swiper('.swiper-container-slider', {
           autoplay: 2000,
        });
    }, 2500);
}).controller('manufacturerproductsController', function($ionicModal,$translate, $ionicLoading ,Customer,Authorization, $timeout,AUTH_EVENTS,Dialog, $scope,$ionicPopup,$ionicPopover,$interval, $rootScope,OpenCart,$state, $stateParams, SafePopups) {
    $scope.page_title =  OpenCart.brand_name;
    $scope.customer = {};
    $scope.contDirModal = {};
    $scope.is_loading = true;
    $scope.value_id = OpenCart.value_id = $stateParams.value_id;
    $scope.base_url = OpenCart.base_url;
    $scope.$on('$ionicView.beforeEnter', function(event, viewData) {
        viewData.enableBack = true;
    });
    /*get all products list on brand page from api*/
    $scope.$on("$ionicView.beforeEnter", function(event, data){
        $scope.loadBrandContent();
    });
    $scope.page = 1;
    $scope.products_lists = new Array();
    $scope.can_load_older_posts = true;
    $scope.noMoreBrandItemsAvailable = false;
     $scope.items = [];
    /*get product details on the basis of product id from api*/
    $scope.productdetails = function(product_id) {
        $state.go("product-details",{ value_id: $scope.value_id, product_id:product_id });
    };
    if(OpenCart.opencart_local_item('opencart_counter') >   0){
        $scope.total_items =  OpenCart.opencart_local_item('opencart_counter');
    }
    $scope.loadBrandContent = function() { 
        OpenCart.brandproductlist($scope.page).success(function(data) {
            OpenCart.base_url   = data.base_url;
            $scope.base_url     = data.base_url;
            $scope.homepage_dynamic_border_color = data.homepage_dynamic_border_color;
            if(data.products == null){
                $scope.noMoreBrandItemsAvailable = true;
            }else{
                $scope.items.push({ id: data.products.length});
                $scope.can_load_older_posts = !!data.products.length;
                $scope.products_lists = $scope.products_lists.concat(data.products);
            }
           
        }).finally(function() {
            $scope.is_loading = false;
        });
    };
    $scope.loadMoreBrandProducts = function() {
        $scope.page++;
        $scope.loadBrandContent();
        $scope.$broadcast('scroll.infiniteScrollComplete');
    };
    /*Add brand product to cart */
    $scope.addBrandProductTocart = function(request_cart_item) {
        OpenCart.p_quantity = $('#p_count').val();
        if(OpenCart.p_quantity >= 1){
            if(OpenCart.opencart_local_item('opencart_user_session_id') && Customer.isLoggedIn()){
                $ionicLoading.show({content: 'Loading',animation: 'fade-in',showBackdrop: true,maxWidth: 200,showDelay: 0 });
                OpenCart.additemtocart(request_cart_item).success(function(data) {
                    $ionicLoading.hide();
                    if(data.cart_api_response_details.success) {
                        $scope.total_items =  OpenCart.opencart_local_item('opencart_counter');
                        OpenCart.set_opencart_local_item('opencart_counter', $scope.total_items++)
                    }
                   $state.go('cart_view', { value_id: $scope.value_id }, { reload: true });
                }).error(function(data) {
                    if(data && angular.isDefined(data.message)) {
                        Dialog.alert($translate.instant("Error"), data.message, $translate.instant("OK"));
                    }

                }).finally(function() {
                    $scope.is_loading = false;
                });
               
            }else{
                /*** section for add product for without login user from brands product listing page ***/
                if(OpenCart.bulk_cart_data == undefined){
                    OpenCart.bulk_cart_data  = [];
                }
                //if not login and click to add to cart then cart data save and after checkout asked user to login
                if(OpenCart.opencart_local_item('opencart_counter') >=   1){
                    $scope.total_items =  OpenCart.opencart_local_item('opencart_counter');
                    OpenCart.set_opencart_local_item('opencart_counter',  $scope.total_items);
                }else{
                    OpenCart.set_opencart_local_item('opencart_counter', 0);
                    if($scope.total_items > 0){
                        OpenCart.set_opencart_local_item('opencart_counter',  $scope.total_items);
                        OpenCart.set_opencart_local_item('cart_bulk_data',  OpenCart.bulk_cart_data);
                    }else{
                        OpenCart.set_opencart_local_item('opencart_counter', 0)
                        OpenCart.bulk_cart_data  = [];
                    }
                    $scope.total_items =  OpenCart.opencart_local_item('opencart_counter');
                    OpenCart.set_opencart_local_item('opencart_counter',  $scope.total_items);
                }
                $scope.localcartitem = request_cart_item;
                OpenCart.guestcartitem = $scope.localcartitem;
                var task_details = [];
                OpenCart.bulk_cart_data.push(request_cart_item);
                OpenCart.set_opencart_local_item('cart_bulk_data',  OpenCart.bulk_cart_data);
                /**now the current user add as guest**/
                OpenCart.additemtolocalsessioncart(request_cart_item).success(function(data) {
                    $scope.is_loading = false;
                    $ionicLoading.hide();
                    if(data.cart_api_response_details) {
                        
                        
                        $scope.total_items =  OpenCart.opencart_local_item('opencart_counter');

                        $scope.total_items++;
                        OpenCart.set_opencart_local_item('opencart_counter', $scope.total_items)
                    }
                });
            }
        }else{
            $ionicPopup.alert({title: $translate.instant('Error'),template: $translate.instant("Please enter valid quantity of prodcct."),buttons: [{ text: $translate.instant("OK") }]});
        
        }
    };

    $scope.cartItemListFromBrandsProducts = function() {
        if(OpenCart.opencart_local_item('opencart_user_session_id')){
            //get all cart item list 
            OpenCart.getapicartdata().success(function(response) {
                if(response.cart_details.success){
                    $scope.list_item = 1;
                    $scope.cart_response_data = response.cart_details.data.products;
                    $scope.total_items = response.cart_item_counter;
                    $scope.cart_response_total = response.cart_details.data.totals;
                }else{
                   $scope.list_item = 0;
                }
               
                $state.go("cart-item-list", { value_id: $scope.value_id, cart:1 });
            }).finally(function() {
                $ionicLoading.hide();
                $scope.is_loading = false;
            });
        }else{
            $state.go("cart-item-list", { value_id: $scope.value_id, cart:1 });
        }
    }

}).controller('CustomerRegistrationController', function($scope, $translate, $location, $ionicLoading, $ionicPopup,Customer,$rootScope,OpenCart,$state, $stateParams, $ionicSlideBoxDelegate, SafePopups) {
    $scope.page_title = $translate.instant("Register Account");
    if(OpenCart.opencart_local_item('opencart_counter') >   0){
        $scope.total_items =  OpenCart.opencart_local_item('opencart_counter');
    }
    $scope.customer = {};
    $scope.is_loading = true;
    $scope.value_id = $stateParams.value_id;
    $scope.base_url = OpenCart.base_url;
    /*get countries  list*/
    $ionicLoading.show({content: 'Loading',animation: 'fade-in',showBackdrop: true,maxWidth: 200,showDelay: 0 });
    $scope.$on('$ionicView.beforeEnter', function(event, viewData) {
         OpenCart.getcountries().success(function(response) {
            $scope.homepage_dynamic_border_color = response.homepage_dynamic_border_color;
            $scope.homepage_dynamic_background_color = response.homepage_dynamic_background_color;
            if(response.countries_list.success){
                $scope.countries = response.countries_list.data;
                OpenCart.countries =  $scope.countries;
                $ionicLoading.hide();
            }
        });
        /*go to login page*/
        $scope.getcountrydetails = function(country_id) {
            if(country_id){
                $ionicLoading.show({content: 'Loading',animation: 'fade-in',showBackdrop: true,maxWidth: 200,showDelay: 0 });
                OpenCart.getcountrydetails(country_id).success(function(response) {
                    $scope.homepage_dynamic_border_color = response.homepage_dynamic_border_color;
                    if(response.country_details.success){
                        $scope.country_zone_details = response.country_details.data.zone;
                        $ionicLoading.hide();
                    }
                });
            }
        };
    });
   
   
    /*go to login page*/
    $scope.gotologin = function(product_id) {
        $state.go("opencart-user-login",{ value_id: $scope.value_id, login:1});
    };
    $scope.opencartRegistration = function(registration_data) {
        OpenCart.unset_opencart_local_item('opencart_user_session_id');
         
        /*Check alert validation*/
        if(registration_data != undefined && registration_data.firstname != undefined  && registration_data.lastname != undefined && registration_data.email != undefined && registration_data.telephone != undefined && registration_data.address_1 && registration_data.city != undefined && registration_data.postcode != undefined && registration_data.country != undefined && registration_data.state != undefined && registration_data.password != undefined ){
            $ionicLoading.show({content: 'Loading',animation: 'fade-in',showBackdrop: true,maxWidth: 200,showDelay: 0 });
           OpenCart.apiregistration(registration_data).success(function(response_data) {
                if(response_data.opencart_login_response.success){
                    $ionicLoading.hide();
                    $scope.opencart_user_session_id = response_data.opencart_user_details.opencart_user_session_id;
                    OpenCart.set_opencart_local_item('opencart_user_session_id',response_data.opencart_user_details.opencart_user_session_id);
                    OpenCart.set_opencart_local_item('opencart_customer_id',response_data.opencart_user_details.customer_id);
                    var register_username = registration_data.email;
                    var register_password = registration_data.password;
                    $scope.customer.email = registration_data.email;
                    $scope.customer.password = registration_data.password;
                    Customer.login($scope.customer).success(function(cdata){
                        OpenCart.set_opencart_local_item('is_have_cart_item_already_then', 1);
                        OpenCart.telephone = response_data.opencart_user_details.telephone;
                        if(OpenCart.guestcartitem){
                            OpenCart.getapicartdata().success(function(data) {
                                if(data.cart_details.success) {
                                    
                                    $scope.total_items =  OpenCart.opencart_local_item('opencart_counter');
                                    OpenCart.set_opencart_local_item('opencart_counter', $scope.total_items++);
                                    //$state.go("checkout-address",{ value_id: $scope.value_id, order:1});
                                     $state.go('checkout-address', { value_id: $scope.value_id,order:1 }, { reload: true });
                                }else{
                                    $scope.total_items =  OpenCart.opencart_local_item('opencart_counter');
                                    $scope.total_items = 0;
                                    OpenCart.set_opencart_local_item('opencart_counter', $scope.total_items);
                                    $ionicPopup.alert({title: $translate.instant('Error'),template: $translate.instant("Sorry!! Unable to add product in shopping cart."),buttons: [{ text: $translate.instant("OK") }]});
                                    $state.go('cart_view', { value_id: $scope.value_id }, { reload: true });

                                }
                               
                            });
                            
                        }else{
                            
                            $state.go("opencart-customer-account", { value_id: $scope.value_id, customer:1 });
                        }
                    });
                }else{
                    $ionicLoading.hide();
                    $ionicPopup.alert({title: $translate.instant('Registration Failed'),template: $translate.instant("Registration Failed, Please try after sometime"),buttons: [{ text: $translate.instant("OK") }]});
                }
            });
        }else  if(registration_data == undefined){
            $ionicPopup.alert({title: $translate.instant('Error'),template: $translate.instant("Please enter the form details."), buttons: [{ text: $translate.instant("OK") }]} );
             
        }else if(registration_data.firstname == undefined){
            $ionicPopup.alert({title: $translate.instant('Error'),template: $translate.instant("Your first name is required."),buttons: [{ text: $translate.instant("OK") }] });
        }else if(registration_data.lastname == undefined){
            $ionicPopup.alert({title: $translate.instant('Error'),template: $translate.instant("Your last name is required."),buttons: [{ text: $translate.instant("OK") }]});
        }else if(registration_data.email == undefined){
            $ionicPopup.alert({title: $translate.instant('Error'),template: $translate.instant("Your email is required."),buttons: [{ text: $translate.instant("OK") }]});
        }else if(registration_data.telephone == undefined){
            $ionicPopup.alert({title: $translate.instant('Error'),template: $translate.instant("Telephone is required."),buttons: [{ text: $translate.instant("OK") }]});
        } else if(registration_data.address_1 == undefined){
            $ionicPopup.alert({title: $translate.instant('Error'),template: $translate.instant("Address 1 is required."),buttons: [{ text: $translate.instant("OK") }]});
        }else if(registration_data.city == undefined){
            $ionicPopup.alert({title: $translate.instant('Error'),template: $translate.instant("City is required."),buttons: [{ text: $translate.instant("OK") }]});
        }else if(registration_data.postcode == undefined){
            $ionicPopup.alert({title: $translate.instant('Error'),template: $translate.instant("City is required."),buttons: [{ text: $translate.instant("OK") }]});
        }else if(registration_data.country == undefined){
            $ionicPopup.alert({title: $translate.instant('Error'),template: $translate.instant("Country is required."),buttons: [{ text: $translate.instant("OK") }]});
        }else if(registration_data.state == undefined){
           $ionicPopup.alert({title: $translate.instant('Error'),template: $translate.instant("State is required."),buttons: [{ text: $translate.instant("OK") }]});
        }else if(registration_data.password == undefined){
            $ionicPopup.alert({title: $translate.instant('Error'),template: $translate.instant("Password is required."),buttons: [{ text: $translate.instant("OK") }]});
        } else{
            $ionicPopup.alert({title: $translate.instant('Registration Failed'),template: $translate.instant("Registration Failed, Please try after sometime"),buttons: [{ text: $translate.instant("OK") }]});
        }
    };
}).controller('opencartUserloginController', function($scope,$ionicModal,$translate,$ionicLoading, Dialog,$ionicPopup,AUTH_EVENTS,Customer, $rootScope,OpenCart,$state, $stateParams, $ionicSlideBoxDelegate, SafePopups) {
    $scope.page_title =  OpenCart.store_name;
    $scope.customer = {};
    $scope.contDirModal = {};
    $scope.base_url = OpenCart.base_url;
   
    $scope.value_id = OpenCart.value_id = $stateParams.value_id;
    $scope.$on('$ionicView.beforeEnter', function(event, viewData) {
        viewData.enableBack = false;
         OpenCart.homepagedynamiccolor().success(function(dynamic_homepage) {
            $scope.homepage_dynamic_border_color = dynamic_homepage.homepage_dynamic_border_color;
            
        });
    });
    /*add back button*/
    $scope.goBack = function() {
        
        $state.go("cart_view", { value_id: $scope.value_id });
    };
    $ionicLoading.hide();
    /*function which is redirect to searc page*/
    $scope.signupCustomer = function() {
        $state.go("customer-registration",{ value_id: $scope.value_id, registration:1 });
    }
    /*forgot password*/
    $scope.openResetPassword = function() {
        $ionicModal.fromTemplateUrl('modules/opencart/templates/l1/reset-password-popup.html', {
            scope: $scope,
            animation: 'slide-in-up'
        }).then(function(modal) {
            $scope.contDirModal.search = modal;
            $scope.contDirModal.search.show();
        });
    };
    $scope.postResetLink = function(reset_email) {
        
        if(reset_email == undefined){
            $ionicPopup.alert({title: $translate.instant('Error'),template: $translate.instant("Please enter email id."),buttons: [{ text: $translate.instant("OK") }]});
        }else{
            OpenCart.resetuserapipassword(reset_email.email).success(function(reset_response) {
                 $ionicLoading.show({content: 'Loading',animation: 'fade-in',showBackdrop: true,maxWidth: 200,showDelay: 0 });
            
                if(reset_response.forgotten_email_response.success){
                    $ionicPopup.alert({title: $translate.instant('Success'),template: $translate.instant("A new password has been sent to your e-mail address."),buttons: [{ text: $translate.instant("OK") }]});
                    $state.go('cart_view', { value_id: $scope.value_id }, { reload: true });
                    $scope.closeModal();
                }else{
                    $ionicPopup.alert({title: $translate.instant('Warning'),template: $translate.instant("The E-Mail Address was not found in our records, please try again!"),buttons: [{ text: $translate.instant("OK") }]});
                }
            }).finally(function() {
                $ionicLoading.hide();
            });

        }
            
        
       
    };
    $scope.opencartlogin = function(opencaruser) {
       $scope.customer.email = opencaruser.username;
        $scope.customer.password = opencaruser.password;

        OpenCart.opencartuserlogin(opencaruser).success(function(data) {
            $ionicLoading.show({content: 'Loading',animation: 'fade-in',showBackdrop: true,maxWidth: 200,showDelay: 0 });
            if(data.opencart_login_response.success) {
                $scope.opencart_user_session_id = data.opencart_user_details.opencart_user_session_id;
                OpenCart.set_opencart_local_item('opencart_user_session_id',data.opencart_user_details.opencart_user_session_id);
                OpenCart.set_opencart_local_item('opencart_customer_id',data.opencart_user_details.customer_id);

                /*Data from opencart live details from API and set to factory variable*/
                OpenCart.firstname  = data.from_opencart_user_details.firstname;
                OpenCart.lastname   = data.from_opencart_user_details.lastname;
                OpenCart.email      = data.from_opencart_user_details.email;
                OpenCart.telephone  = data.from_opencart_user_details.telephone;

                Customer.login($scope.customer).success(function(cdata) {
                    //add cart item after login by user
                    if(OpenCart.guestcartitem){
                        OpenCart.additemtocart(OpenCart.guestcartitem).success(function(data) {
                            $scope.total_items =  OpenCart.opencart_local_item('opencart_counter');
                            OpenCart.set_opencart_local_item('opencart_counter', $scope.total_items++)
                        });
                    }
                    if(OpenCart.guestwishlist){
                        OpenCart.addtowhishlist().success(function(whishlistresponse) {
                            if(whishlistresponse.addtowishlist.success) {
                               $ionicPopup.alert({title: $translate.instant('Success'),template: $translate.instant("Product added to wishlist successfully"),buttons: [{ text: $translate.instant("OK") }]});
                            } else if(whishlistresponse.addtowishlist=='Already exists'){
                                $ionicPopup.alert({title: $translate.instant('Already exists'),template: $translate.instant("This product already added into wishlist."),buttons: [{ text: $translate.instant("OK") }]});
                            }else {
                               $ionicPopup.alert({title: $translate.instant('Error'),template: $translate.instant("Unable to add wishlist"),buttons: [{ text: $translate.instant("OK") }]});
                            }
                        });
                    }
                    if(cdata && cdata.success) {
                        OpenCart.getapicartdata().success(function(response) {
                            OpenCart.set_opencart_local_item('opencart_counter',response.cart_item_counter);
                            if(OpenCart.opencart_local_item('is_have_cart_item_already_then') == 1 ){
                                /*This condition work on those users who added a product without login and after login they redirect on address selection process*/
                                $state.go("checkout-address",{ value_id: $scope.value_id, order:1});
                            }else{
                                /*This is for those users who login and those who have no items in cart*/
                                $state.go("cart_view", { value_id: $scope.value_id });
                            }
                            
                        });
                        $ionicLoading.hide();
                    }
                });
                
            }else{
                $ionicLoading.hide();
                $ionicPopup.alert({title: $translate.instant('Login Failed'),template: $translate.instant("Username or password not matched."),buttons: [{ text: $translate.instant("OK") }]});
            }
        });
    };
    /**
    * Remove all opened Contact Directory modals at once
    */
    $scope.closeModal = function() {
        if(angular.isObject($scope.contDirModal)) {
            for (var i in $scope.contDirModal) {
                if(angular.isObject($scope.contDirModal[i]) && angular.isFunction($scope.contDirModal[i].remove)) {
                    $scope.contDirModal[i].remove();
                }
            }
        }
    }
}).controller('categoryController', function($scope,$ionicPopup, $translate, $ionicModal, $ionicLoading, $rootScope,OpenCart,$state, Customer, $stateParams, $ionicSlideBoxDelegate,$timeout, SafePopups) {
    $scope.layout = 'list';
    $scope.base_url = OpenCart.base_url;
    $scope.contDirModal = {};
    $scope.cpage = 1;
    $scope.noMoreCatItemsAvailable = true;
    $scope.is_loading = true;
    $scope.value_id = OpenCart.value_id = $stateParams.value_id;
    $scope.$on('$ionicView.beforeEnter', function(event, viewData) {
        viewData.enableBack = true;
    });
    if(OpenCart.opencart_local_item('opencart_counter') >   0){
        $scope.total_items =  OpenCart.opencart_local_item('opencart_counter');
    }
    $scope.category_products_lists = new Array();
    /*Get product details*/
    $scope.productdetails = function(product_id) {
        $state.go("product-details",{ value_id: $scope.value_id, product_id:product_id });
    };
    /*get default category  from api*/
    $scope.$on("$ionicView.beforeEnter", function(event, data){
        $scope.loadCategoryProducts();
    });
    /*get category product details*/  
    $scope.loadCategoryProducts = function() {
        OpenCart.getcategoryproduct( $scope.cpage, OpenCart.by_manufacturer_id).success(function(data_details) {
            $scope.page_title = OpenCart.category_name;
            $scope.homepage_dynamic_border_color = data_details.homepage_dynamic_border_color;
            if(data_details.products){
                $scope.is_loading = false;
                OpenCart.by_manufacturer_id = 0;
                $scope.cat_products_found = 1;
                $scope.category_products_lists = $scope.category_products_lists.concat(data_details.products);
                $scope.cat_items.push({ id: data_details.products.length});
                $scope.noMoreCatItemsAvailable = !!data_details.products.length;

            }else{
                $scope.cat_products_found = 0;
                $scope.noMoreCatItemsAvailable = false;
            }
            
        }).finally(function() {
            $scope.is_loading = false;
        });
    };
    $scope.cat_items = [];

    $scope.loadMoreCategory = function() {
        $scope.cpage++;
        $scope.loadCategoryProducts();
        $scope.$broadcast('scroll.infiniteScrollComplete');
    };
    /*get all categories*/ 
    OpenCart.getcategories().success(function(category_data) {
        $ionicLoading.hide();
        $scope.category_list = category_data.category_list;
    });
    $scope.sortby_name_a_to_z        = 'pd.name&order=ASC'; 
    $scope.sortby_name_z_to_a        = 'pd.name&order=DESC';
    $scope.sortby_price_low_to_high  = 'price&order=asc'; 
    $scope.sortby_price_high_to_low  = 'price&order=desc'; 
    $scope.sortby_rating_highest     = 'rating&order=DESC';
    $scope.sortby_rating_lowest      = 'rating&order=ASC';
    $scope.sortby_model_a_to_z       = 'model&order=ASC';
    $scope.sortby_model_z_to_a       = 'model&order=DESC';
    /*sorting modal box*/
    $scope.openSortpopup = function() {
        $ionicModal.fromTemplateUrl('modules/opencart/templates/l1/sort-modal-box.html', {
            scope: $scope,
            animation: 'slide-in-up'
        }).then(function(modal) {
            $scope.contDirModal.search = modal;
            $scope.contDirModal.search.show();
        });
    };
    
    $scope.sortproducts = function(sortfilert){
        $scope.closeModal();
        OpenCart.product_filter = sortfilert;
        $ionicLoading.show({
            content: 'Loading',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        OpenCart.category_id = $stateParams.sub_category_id;
        OpenCart.sortproductsbyfilter().success(function(sorted_response) {
            $ionicLoading.hide();
            $scope.category_products_lists = sorted_response.products;
        });
    };
    /*refine submit form*/
    $scope.refineCategoryProducts = function(refine_request_data) {
        if(refine_request_data != undefined){
            $ionicLoading.show({content: 'Loading',animation: 'fade-in',showBackdrop: true,maxWidth: 200,showDelay: 0 });
            var freine_page = 1;
            var category_url = OpenCart.category_url;
            OpenCart.getrefineproduct(freine_page,refine_request_data,category_url).success(function(refine_response_data) {
                $scope.closeModal();
                $ionicLoading.hide();
                if(refine_response_data.products !=0){
                      $scope.noMoreCatItemsAvailable = false;
                    $scope.category_products_lists = refine_response_data.products;
                    $scope.cat_products_found = 1;
                    $scope.closeModal();
                    $ionicLoading.hide();
                    OpenCart.by_manufacturer_id = 0;
                    $scope.closeModal();
                    $ionicLoading.hide();
                }else{
                    $scope.noMoreCatItemsAvailable = false;
                    $scope.cat_products_found = 0;
                    $scope.closeModal();
                    $ionicLoading.hide();
                    OpenCart.by_manufacturer_id = 0;
                    $ionicPopup.alert({title: $translate.instant('Empty'),template: $translate.instant("There are no products for this category."),buttons: [{ text: $translate.instant("OK") }]});
                    $scope.closeModal();
                    $ionicLoading.hide();
                }
            });
        }else{
            $scope.closeModal();
            $ionicLoading.hide();
        }
    };
    /* catgory refine search model to popup*/
    $scope.openRefineform = function() {
        $ionicLoading.show({content: 'Loading',animation: 'fade-in',showBackdrop: true,maxWidth: 200,showDelay: 0 });
        OpenCart.getcategoriesdepthlevel().success(function(refine_data) {
            angular.forEach( refine_data.refine.filters.filter_groups, function(f_group, key) {
                if(f_group.name == 'Marca' || f_group.name == 'Brand' ){
                    $scope.refine_brand = f_group.filter;
                }
                if(f_group.name == 'Côr' || f_group.name == 'Color' ){
                    $scope.refine_color = f_group.filter;
                }
                 if(f_group.name == 'Preço' || f_group.name == 'Price' ){
                    $scope.refine_price = f_group.filter;
                }
            });
        }).finally(function() {
            $ionicLoading.hide();
        });
        $ionicModal.fromTemplateUrl('modules/opencart/templates/l1/catgory-refine-search.html', {
            scope: $scope,
            animation: 'slide-in-up'
        }).then(function(modal) {
            $scope.contDirModal.search = modal;
            $scope.contDirModal.search.show();
        });
    };
    /**
    * Remove all opened Contact Directory modals at once
    */
    $scope.closeModal = function() {
        if(angular.isObject($scope.contDirModal)) {
            for (var i in $scope.contDirModal) {
                if(angular.isObject($scope.contDirModal[i]) && angular.isFunction($scope.contDirModal[i].remove)) {
                    $scope.contDirModal[i].remove();
                }
            }
        }
    }
    /*get category product lists*/
    $scope.getcategoryproducts = function(category_id,category_name , category_url, sub_category_id) {
        OpenCart.category_name = category_name;
        OpenCart.sub_category_id = sub_category_id;
        $scope.page_title = category_name;
        OpenCart.category_url = category_url;
        $scope.closeModal();
        $state.go("category-product-list",{ value_id: $scope.value_id, category_id:category_id,sub_category_id:sub_category_id });
   };
   $scope.cartItemListFromCategoryList = function() {
        if(OpenCart.opencart_local_item('opencart_user_session_id')){
            //get all cart item list 
            OpenCart.getapicartdata().success(function(response) {
                if(response.cart_details.success){
                    $scope.list_item = 1;
                    $scope.cart_response_data = response.cart_details.data.products;
                    $scope.total_items = response.cart_item_counter;
                    $scope.cart_response_total = response.cart_details.data.totals;
                }else{
                   $scope.list_item = 0;
                }
               
                $state.go("cart-item-list", { value_id: $scope.value_id, cart:1 });
            }).finally(function() {
                $ionicLoading.hide();
                $scope.is_loading = false;
            });
        }else{
            $state.go("cart-item-list", { value_id: $scope.value_id, cart:1 });
        }
    }
    /*Add brand product to cart */
    $scope.addCategoryProductTocart = function(request_cart_item) {
        OpenCart.p_quantity = $('#p_count').val();
        if(OpenCart.p_quantity >= 1){
            if(OpenCart.opencart_local_item('opencart_user_session_id') && Customer.isLoggedIn()){
                $ionicLoading.show({content: 'Loading',animation: 'fade-in',showBackdrop: true,maxWidth: 200,showDelay: 0 });
                OpenCart.additemtocart(request_cart_item).success(function(data) {
                    $ionicLoading.hide();
                    if(data.cart_api_response_details.success) {
                        $ionicPopup.alert({title: $translate.instant('Add to cart'),template: $translate.instant("Add to cart successfully."),buttons: [{ text: $translate.instant("OK") }]});
                        $scope.total_items =  OpenCart.opencart_local_item('opencart_counter');
                        OpenCart.set_opencart_local_item('opencart_counter', $scope.total_items++)
                    }else{
                        $ionicPopup.alert({title: $translate.instant('Error'),template: $translate.instant("Sorry!! Unable to add product in shopping cart."),buttons: [{ text: $translate.instant("OK") }]});
                    }
                    $state.go('cart_view', { value_id: $scope.value_id }, { reload: true });
                }).error(function(data) {
                    if(data && angular.isDefined(data.message)) {
                        Dialog.alert($translate.instant("Error"), data.message, $translate.instant("OK"));
                    }
                }).finally(function() {
                    $scope.is_loading = false;
                });
            }else{
                /**add  product to local sesssion for whitout login user**/
                if(OpenCart.bulk_cart_data == undefined){
                    OpenCart.bulk_cart_data  = [];
                }
                //if not login and click to add to cart then cart data save and after checkout asked user to login
                if(OpenCart.opencart_local_item('opencart_counter') >=   1){
                    $scope.total_items =  OpenCart.opencart_local_item('opencart_counter');
                }else{
                    OpenCart.set_opencart_local_item('opencart_counter', 0);
                    if($scope.total_items > 0){
                        OpenCart.set_opencart_local_item('opencart_counter',  $scope.total_items);
                        OpenCart.set_opencart_local_item('cart_bulk_data',  OpenCart.bulk_cart_data);
                    }else{
                        OpenCart.set_opencart_local_item('opencart_counter', 0)
                        OpenCart.bulk_cart_data  = [];
                    }
                    $scope.total_items =  OpenCart.opencart_local_item('opencart_counter');
                    OpenCart.set_opencart_local_item('opencart_counter',  $scope.total_items);
                }
                $scope.localcartitem = request_cart_item;
                OpenCart.guestcartitem = $scope.localcartitem;
                var task_details = [];
                OpenCart.bulk_cart_data.push(request_cart_item);
                OpenCart.set_opencart_local_item('cart_bulk_data',  OpenCart.bulk_cart_data);
                /**now the current user add as guest**/
                OpenCart.additemtolocalsessioncart(request_cart_item).success(function(data) {
                    $scope.is_loading = false;
                    $ionicLoading.hide();
                    if(data.cart_api_response_details) {
                        $ionicPopup.alert({title: $translate.instant('Add to cart'),template: $translate.instant("Add to cart successfully."),buttons: [{ text: $translate.instant("OK") }]});
                        $scope.total_items =  OpenCart.opencart_local_item('opencart_counter');
                        $scope.total_items++;
                        OpenCart.set_opencart_local_item('opencart_counter', $scope.total_items)
                    }else{
                       $ionicPopup.alert({title: $translate.instant('Error'),template: $translate.instant("Sorry!! Unable to add product in shopping cart."),buttons: [{ text: $translate.instant("OK") }]});
                    }
                });
            }
        }else{
            $ionicPopup.alert({title: $translate.instant('Error'),template: $translate.instant("Please enter valid quantity of prodcct."),buttons: [{ text: $translate.instant("OK") }]});
        }
    };   
}).controller('productdetailController', function($scope,$parse,$interpolate,$cordovaSocialSharing, $translate, $ionicLoading,$ionicModal, $timeout, Customer, $ionicPopup ,$rootScope,OpenCart,$state, $stateParams, $ionicSlideBoxDelegate, $location,SafePopups) {
    $scope.contDirModal = {};
    $scope.base_url = OpenCart.base_url;
    $scope.page_title =  OpenCart.store_name;
    $scope.is_loading = true;
    $scope.value_id = OpenCart.value_id = $stateParams.value_id;

    /*initialize the product quantity*/
    $scope.rating = 1;     
    $scope.minRating = 1;
    $scope.maxRating = 100;
    OpenCart.p_quantity = 1;
    $scope.my_rating = 0;
    OpenCart.myrating = 0;
    var current_url = $location.url();
    if(OpenCart.opencart_local_item('opencart_counter') >   0){
        $scope.total_items =  OpenCart.opencart_local_item('opencart_counter');
    }
    /*get the product details*/
    OpenCart.getproductdetails().success(function(product_data) {
        //get manufature details
        $scope.homepage_dynamic_border_color = product_data.homepage_dynamic_border_color;
        
        OpenCart.getmanufacturerdetails(product_data.products.manufacturer_id).success(function(getmanufacturer_response) {
           $scope.manufacturer_details = getmanufacturer_response.manufacturer_details;
        });
        $scope.product_slider_images = [];
        $scope.product_data = product_data.products;
        $scope.cartitem = {product_id: product_data.products.id, price:product_data.products.price,thumb:product_data.products.image,name:product_data.products.name,special_formated:product_data.products.special_formated};
        /*facebook like code */
        $scope.myModel = {
            Url: 'https://www.lojadosbebes.pt/carrinho-para-gemeos-ovo-twin-133',
            Name: product_data.products.name, 
            ImageUrl: product_data.products.image
        };
        var break_product_name = product_data.products.name.split("-");
        if(break_product_name[1] != undefined){
            var url_product_name = break_product_name[1].trim();
            var convert_name_to_lower = angular.lowercase(url_product_name);
            var product_name_break_arr = convert_name_to_lower.split(" ");
            var pre_url_like = '';
            angular.forEach(product_name_break_arr, function(product_url_name, key) {
                pre_url_like += product_url_name+'-';
            });
            var filetr_url = pre_url_like.replace(/\,!/g,"");
            var product_details_url = filetr_url+product_data.products.id+'?manufacturer_id='+product_data.products.manufacturer_id;//'a-hora-da-papa-11?manufacturer_id=28';
        }else{
            var product_name_break_arr = product_data.products.name.split(" ");
            var url_like = '';
            angular.forEach(product_name_break_arr, function(product_url_name, key) {
                url_like += product_url_name+'-';
            });
            var product_details_url = url_like+product_data.products.id;//'a-hora-da-papa-11?manufacturer_id=28';
        }
        OpenCart.getappapidetails().success(function(appapiresponse){
            $scope.facebook_app_id = appapiresponse.facebook_app_id;
            if(appapiresponse.facebook_app_id){
                $scope.is_facebook_app_id = 1;
                $scope.facebook_app_id = appapiresponse.facebook_app_id;
            }else{
                $scope.is_facebook_app_id = 0;
            }
        }).finally(function() {
            var AppId = $scope.facebook_app_id;
            $scope.likeproducturl =  'https://www.facebook.com/plugins/like.php?href=https%3A%2F%2Fwww.lojadosbebes.pt%2F'+product_details_url+'&width=134&layout=button_count&action=like&size=small&show_faces=false&share=false&height=46&appId='+AppId;
        });
        var main_image = product_data.products.image;
        $scope.product_slider_images.push(main_image);
        $scope.have_multi_image = 0;
        if(product_data.products.images.length > 1){
            $scope.have_multi_image = 1;
            angular.forEach(product_data.products.images, function(product_image, key) {
                $scope.product_slider_images.push(product_image);
            });
            $scope.slidePrevious = function() {
                $ionicSlideBoxDelegate.previous();
            }
            $scope.slideNext = function() {
                $ionicSlideBoxDelegate.next();
            }
        }
        if(product_data.products.reviews.review_total >= 1){
            $scope.total_comment_counts = product_data.products.reviews.review_total;
            $scope.total_reviews = product_data.products.reviews.reviews;
        }
    }).finally(function() {
        $scope.is_loading = false;
    });
    $scope.updateSlider = function() {
        $ionicSlideBoxDelegate.update(); 
    }
    /*get totals revies*/
    $scope.totalComments = function() {
        $scope.total_comments = $scope.total_comment_counts;
        $ionicModal.fromTemplateUrl('modules/opencart/templates/l1/total-reviews-popup.html', {
            scope: $scope,
            animation: 'slide-in-up'
        }).then(function(modal) {
            $scope.contDirModal.search = modal;
            $scope.contDirModal.search.show();
        });
    };
    /*get totals revies*/
    $scope.newComment = function() {
        $scope.total_comments = $scope.total_comment_counts;
        $ionicModal.fromTemplateUrl('modules/opencart/templates/l1/post-new-comments.html', {
            scope: $scope,
            animation: 'slide-in-up'
        }).then(function(modal) {
            $scope.contDirModal.search = modal;
            $scope.contDirModal.search.show();
        });
    };
    /*Counting star rating*/
    $scope.submitStar=function(user){
        $scope.my_rating = user.answer;
    };
    /*post comments*/
    $scope.postComments = function(post_comment_data) {
        OpenCart.myrating = $('#myrating').val();
        if(OpenCart.myrating >= 1){
            $ionicLoading.show({content: 'Loading',animation: 'fade-in',showBackdrop: true,maxWidth: 200,showDelay: 0 });
            OpenCart.postcomment(post_comment_data).success(function(data) {
                $ionicLoading.hide();
                if(data.comment_response.success) {
                    $ionicPopup.alert({title: $translate.instant('Comment'),template: $translate.instant("Your comment have successfully sumbit."),buttons: [{ text: $translate.instant("OK") }]});
                }else{
                    $ionicPopup.alert({title: $translate.instant('Error'),template: $translate.instant("Sorry!! Unable to add your comment."),buttons: [{ text: $translate.instant("OK") }]});
                }
                $state.go('product-details', { value_id: $scope.value_id, product_id: $stateParams.product_id }, { reload: true });
                $scope.closeModal();
            }).error(function(data) {
                if(data && angular.isDefined(data.message)) {
                    Dialog.alert($translate.instant("Error"), data.message, $translate.instant("OK"));
                }
            }).finally(function() {
                $scope.is_loading = false;
            });
        }else{
           $ionicPopup.alert({title: $translate.instant('Error'),template: $translate.instant("Sorry!! Unable to add your comment.Please select stars."),buttons: [{ text: $translate.instant("OK") }]});
        }
    };
    /*socail sharing of product*/
    $scope.whatsappShare=function(product_name, product_image){ 
        /*Share with Whatsup*/
        window.plugins.socialsharing.shareViaWhatsApp(product_name, product_image, OpenCart.base_url+"/var/apps/browser/index-prod.html#"+current_url /* url */, null, function(errormsg){/*alert("Error: Cannot Share")*/});
    }
    $scope.facebookShare=function(product_name, product_image){
        /*Share with Facebook*/

        window.plugins.socialsharing.shareViaFacebook(product_name, product_image, OpenCart.base_url+"/var/apps/browser/index-prod.html#"+current_url, null, function(errormsg){/*alert("Error: Cannot Share")*/});
    }
    $scope.twitterShare=function(product_name, product_image){
         /*Share with Twitter*/
        window.plugins.socialsharing.shareViaTwitter(product_name, product_image, OpenCart.base_url+"/var/apps/browser/index-prod.html#"+current_url, null, function(errormsg){/*alert("Error: Cannot Share")*/});
    }
    $scope.OtherShare=function(product_name, product_image){
        /*Share with all options available in mobile device*/
        window.plugins.socialsharing.share(product_name, product_image, null, OpenCart.base_url+"/var/apps/browser/index-prod.html#"+current_url);
    }
    /**Remove modelbox*/
    $scope.closeModal = function() {
        if(angular.isObject($scope.contDirModal)) {
            for (var i in $scope.contDirModal) {
                if(angular.isObject($scope.contDirModal[i]) && angular.isFunction($scope.contDirModal[i].remove)) {
                    $scope.contDirModal[i].remove();
                }
            }
        }
    }
    /*add back button*/
    $scope.goBack = function() {
        $state.go("cart_view", { value_id: $scope.value_id });
    };
    /*add share button view*/
    $scope.shareWithFriend = function() {
        $state.go("cart_view", { value_id: $scope.value_id });
    }
    $scope.addTocart = function(request_cart_item) {
        OpenCart.p_quantity = $('#p_value_counter').val();
       
        if(OpenCart.p_quantity >= 1){
            if(OpenCart.opencart_local_item('opencart_user_session_id') && Customer.isLoggedIn()){
                $ionicLoading.show({content: 'Loading',animation: 'fade-in',showBackdrop: true,maxWidth: 200,showDelay: 0 });
                OpenCart.additemtocart(request_cart_item).success(function(data) {
                    $ionicLoading.hide();
                    if(data.cart_api_response_details.success) {
                        $ionicPopup.alert({title: $translate.instant('Add to cart'),template: $translate.instant("Add to cart successfully."),buttons: [{ text: $translate.instant("OK") }]});
                        $scope.total_items +=  OpenCart.opencart_local_item('opencart_counter');
                        OpenCart.set_opencart_local_item('opencart_counter', $scope.total_items)
                    }else{
                        $ionicPopup.alert({title: $translate.instant('Error'),template: $translate.instant("Sorry!! Unable to add product in shopping cart."),buttons: [{ text: $translate.instant("OK") }]});
                    }
                    $state.go("cart_view", { value_id: $scope.value_id });
                }).error(function(data) {
                    if(data && angular.isDefined(data.message)) {
                        Dialog.alert($translate.instant("Error"), data.message, $translate.instant("OK"));
                    }
                }).finally(function() {
                    $scope.is_loading = false;
                });
               
            }else{
                /*not login user and trying to add product from product details page*/
                $scope.localcartitem = request_cart_item;
                OpenCart.guestcartitem = $scope.localcartitem;
                if(OpenCart.bulk_cart_data == undefined){
                    OpenCart.bulk_cart_data  = [];
                }
                if(OpenCart.opencart_local_item('opencart_counter') >   0){
                    $scope.total_items =  OpenCart.opencart_local_item('opencart_counter');
                    $scope.total_items ++;
                    OpenCart.set_opencart_local_item('opencart_counter',  $scope.total_items);
                }else{
                    OpenCart.set_opencart_local_item('opencart_counter', 0);
                    if($scope.total_items > 0){
                        OpenCart.set_opencart_local_item('opencart_counter',  $scope.total_items);
                        OpenCart.set_opencart_local_item('cart_bulk_data',  OpenCart.bulk_cart_data);
                    }else{
                        OpenCart.set_opencart_local_item('opencart_counter', 0)
                        OpenCart.bulk_cart_data  = [];
                    }
                    $scope.total_items =  OpenCart.opencart_local_item('opencart_counter');
                    $scope.total_items ++;
                    OpenCart.set_opencart_local_item('opencart_counter',  $scope.total_items);
                }
                $scope.localcartitem = request_cart_item;
                OpenCart.guestcartitem = $scope.localcartitem;
                var task_details = [];
                OpenCart.bulk_cart_data.push(request_cart_item);
                OpenCart.set_opencart_local_item('cart_bulk_data',  OpenCart.bulk_cart_data);
                /**now the current user add as guest**/
                OpenCart.additemtolocalsessioncart(request_cart_item).success(function(data) {
                    $scope.is_loading = false;
                    $ionicLoading.hide();
                    $state.go("cart_view", { value_id: $scope.value_id });
                });
            }
        }else{
            $ionicPopup.alert({title: $translate.instant('Error'),template: $translate.instant("Please enter valid quantity of prodect."),buttons: [{ text: $translate.instant("OK") }]});
        }
    };
    /*add to wish list*/
    $scope.addtoWishlist = function(wishlist_product_id) {
        $ionicLoading.show({content: 'Loading',animation: 'fade-in',showBackdrop: true,maxWidth: 200,showDelay: 0 });
        OpenCart.guestwishlist = wishlist_product_id;
        OpenCart.whishlist_product_id = wishlist_product_id;
        $scope.whishlist_product_id = wishlist_product_id;
        $('.heart-none').addClass('heart-none active');
        if(OpenCart.opencart_local_item('opencart_user_session_id')){
            OpenCart.addtowhishlist().success(function(whishlistresponse) {
                $ionicLoading.hide();
                if(whishlistresponse.addtowishlist.success) {
                    $ionicPopup.alert({title: $translate.instant('Success'),template: $translate.instant("Product added to wishlist successfully."),buttons: [{ text: $translate.instant("OK") }]});
                } else if(whishlistresponse.addtowishlist=='Already exists'){
                    $ionicPopup.alert({title: $translate.instant('Already exists'),template: $translate.instant("This product already added into wishlist."),buttons: [{ text: $translate.instant("OK") }]});
                }else {
                    $ionicPopup.alert({title: $translate.instant('Error'),template: $translate.instant("Unable to add wishlist."),buttons: [{ text: $translate.instant("OK") }]});
                }
            });
        }else{
            $state.go("opencart-user-login",{ value_id: $scope.value_id, login:1});
        }
    }
    $scope.brandProductList = function(manufacturer_id,brand_name) {
        OpenCart.brand_name = brand_name;

        $state.go("product-list-by-manufacturer",{ value_id: $scope.value_id, manufacturer_id:manufacturer_id });
    };
    $scope.cartItemListFromProductDetails = function() {
        if(OpenCart.opencart_local_item('opencart_user_session_id')){
            //get all cart item list 
            OpenCart.getapicartdata().success(function(response) {
                if(response.cart_details.success){
                    $scope.list_item = 1;
                    $scope.cart_response_data = response.cart_details.data.products;
                    $scope.total_items = response.cart_item_counter;
                    $scope.cart_response_total = response.cart_details.data.totals;
                }else{
                   $scope.list_item = 0;
                }
                $state.go("cart-item-list", { value_id: $scope.value_id, cart:1 });
            }).finally(function() {
                $ionicLoading.hide();
                $scope.is_loading = false;
            });
        }else{
            $state.go("cart-item-list", { value_id: $scope.value_id, cart:1 });
        }
    }
}).controller('OpenCartUserController', function($scope,$translate, $ionicLoading, $ionicModal,Customer, Authorization, $rootScope,OpenCart,$state, $stateParams,FacebookConnect,SafePopups) {
    $scope.page_title = $translate.instant("Account");
    $scope.contDirModal = {};
    $scope.base_url = OpenCart.base_url;
    $scope.isDisabled1 = true;
    $scope.value_id = OpenCart.value_id = $stateParams.value_id;
    $scope.$on('$ionicView.beforeEnter', function(event, viewData) {
        viewData.enableBack = false;
    });
   
    $ionicLoading.show({content: 'Loading',animation: 'fade-in',showBackdrop: true,maxWidth: 200,showDelay: 0 });
    /*Upper button enable and disable*/
    $scope.account_view = function(){
        $scope.isDisabled1 = true;
        $scope.isDisabled2 = false;
    }
    $scope.order_view = function(){
        $scope.isDisabled1 = false;
        $scope.isDisabled2 = true;
    }
    if(OpenCart.opencart_local_item('opencart_counter') >   0){
        $scope.total_items =  OpenCart.opencart_local_item('opencart_counter');
    }
    /*send data to page*/
    Customer.find().success(function(user_data) {
        if(!user_data.id){
            OpenCart.unset_opencart_local_item('opencart_user_session_id');
            $state.go("opencart-user-login",{ value_id: $scope.value_id, login:1});
        }else{

            $scope.customer_id = user_data.id;
            $scope.location = user_data.location;
            /*get the  latest user details from opencart*/
            OpenCart.getuserlatestdetailsfromapi().success(function(latest_user_response) {
               if(latest_user_response.updated_opencart_custoemr_details.success){
                   
                    $scope.userfullname = latest_user_response.updated_opencart_custoemr_details.data.firstname + " " + latest_user_response.updated_opencart_custoemr_details.data.lastname;
                    $scope.useremail = latest_user_response.updated_opencart_custoemr_details.data.email;
                    $scope.telephone = latest_user_response.updated_opencart_custoemr_details.data.telephone;
                }else{
                    $scope.userfullname = user_data.firstname + " " + user_data.lastname;
                    $scope.useremail = user_data.email;
                    $scope.telephone = OpenCart.telephone;
                }
                $ionicLoading.hide();
            });
            $ionicLoading.hide();
        }
    }).finally(function() {
        
        $scope.is_loading = false;
    });
    $scope.getOrderDetails = function(order_id) {
        $ionicLoading.show({content: 'Loading',animation: 'fade-in',showBackdrop: true,maxWidth: 200,showDelay: 0 });
        OpenCart.getocorderdetails(order_id).success(function(response) {
            if(response.view_order_details.success){
                $scope.order_view_details = response.view_order_details.data;
                $scope.order_products_view_details = response.view_order_details.data.products;
                $scope.order_totals_view_details = response.view_order_details.data.totals;
                $scope.all_p_images = response.p_images;
                $ionicModal.fromTemplateUrl('modules/opencart/templates/l1/order_view_details_popup.html', {
                    scope: $scope,
                    animation: 'slide-in-up'
                }).then(function(modal) {
                    $scope.contDirModal.search = modal;
                    $scope.contDirModal.search.show();
                    $ionicLoading.hide();
                });
            }
        });   
    }
    /*get order details*/
    $scope.getuserOrders = function() {
        $ionicLoading.show({content: 'Loading',animation: 'fade-in',showBackdrop: true,maxWidth: 200,showDelay: 0 });
        $scope.opencart_c_id = OpenCart.opencart_local_item('opencart_customer_id');
        OpenCart.getopencartuserorder( $scope.opencart_c_id).success(function(response) {
            if(response.order_details === false){
                $scope.total_order_count = 0;
            }else{
                $scope.total_order_count = 1;
                $scope.customer_orders = response.order_details;
            }
        }).then(function() {
                $ionicLoading.hide();   
        });
    };
    $scope.opencartUser = function() {
        $state.go("opencart-customer-account", { value_id: $scope.value_id, customer:1 });
    }
    $scope.editopencartuser = function() {
        $ionicModal.fromTemplateUrl('templates/customer/account/l1/login.html', {
            scope: $scope,
            animation: 'slide-in-up'
        }).then(function(modal) {
            Customer.modal = modal;
            Customer.modal.show();
        });
    };
    $scope.opencartHome = function() {
        $state.go("cart_view",{ value_id: $scope.value_id});
    };
    /*This function use for log out user*/
    $scope.logout = function() {
        $ionicLoading.show({content: 'Loading',animation: 'fade-in',showBackdrop: true,maxWidth: 200,showDelay: 0 });
        Customer.logout().success(function(data) {
            if(data.success) {
                $scope.is_logged_in = false;
                $scope.opencart_user_session_id = null;
                OpenCart.unset_opencart_local_item('opencart_user_session_id');
                OpenCart.unset_opencart_local_item('opencart_customer_id');
                OpenCart.unset_opencart_local_item('opencart_counter');
                OpenCart.unset_opencart_local_item('payment_by');
                OpenCart.unset_opencart_local_item('address_id');
                OpenCart.unset_opencart_local_item('opencart_guest_counter');
                OpenCart.unset_opencart_local_item('is_have_cart_item_already_then');
                OpenCart.total_cart_item = 0;
                OpenCart.guestwishlist = '';
                OpenCart.guestcartitem = '';
                $ionicLoading.hide();
                $state.go("cart_view", { value_id: $scope.value_id });
            }
        });
    };
    /*function which is redirect to searc page*/
    $scope.gotosearch = function() {
        $state.go("search-page",{ value_id: $scope.value_id, search:1 });
    }
    /*get wish list data for user*/
    $scope.getAllwistList = function() {
       $state.go("customer-wishlist",{ value_id: $scope.value_id, wishlist:1});
    }
    /**
    * Remove all opened Contact Directory modals at once
    */
    $scope.closeModal = function() {
        if(angular.isObject($scope.contDirModal)) {
            for (var i in $scope.contDirModal) {
                if(angular.isObject($scope.contDirModal[i]) && angular.isFunction($scope.contDirModal[i].remove)) {
                    $scope.contDirModal[i].remove();
                }
            }
        }
    }
}).controller('CartItemListController', function($scope,$translate,$ionicLoading, Customer,$timeout, $ionicPopup, $rootScope,OpenCart,$state, $stateParams, $ionicSlideBoxDelegate, SafePopups) {
    $scope.page_title =   $translate.instant("Total Cart Items"),
    $scope.is_loading = true;
    $scope.base_url = OpenCart.base_url;
    $scope.value_id = OpenCart.value_id = $stateParams.value_id;
    if(OpenCart.opencart_local_item('opencart_counter') >   0){
        $scope.total_items =  OpenCart.opencart_local_item('opencart_counter');
    }
    /*function which are use for checkout button on item list page*/
    $scope.checkoutprocess = function() {
        $state.go("checkout-address",{ value_id: $scope.value_id, order:1});
    };
    $scope.$on("$ionicView.beforeEnter", function(event, data){
        if(OpenCart.opencart_local_item('opencart_user_session_id')){
            OpenCart.getapicartdata().success(function(response) {
                $scope.is_loading = false;
                if(response.cart_details=='error'){
                    $scope.list_item = 0;
                }else{
                    $scope.list_item = 1;
                    $scope.cart_response_data = response.cart_details.data.products;
                    $scope.cart_response_total = response.cart_details.data.totals;
                    $scope.total_items = response.cart_item_counter;
                    $scope.products = response.cart_details.products;
                }
                $state.go("cart-item-list", { value_id: $scope.value_id, cart:1 });
            });
        }else{
            OpenCart.getitemtolocalsessioncart().success(function(cart_view_product_data) {
                $scope.is_loading = false;
                $ionicLoading.hide();
                if(cart_view_product_data.cart_api_response_details == null){
                    $scope.cart_list_item_without_login = 0;
                    $scope.list_item = 0;
                }else{
                    if(cart_view_product_data.cart_api_response_details.length > 0) {
                        $scope.cart_list_item_without_login = 1;
                        $scope.cart_response_data = cart_view_product_data.cart_api_response_details;
                        $scope.local_cart_sub_total = 0;
                        angular.forEach( cart_view_product_data.cart_api_response_details, function(local_cart_product, key) {
                           $scope.local_cart_sub_total +=  parseFloat(local_cart_product.special_price);
                        });
                        $scope.local_cart_total = $scope.local_cart_sub_total;
                    }else{
                        $scope.cart_list_item_without_login = 0;
                        $scope.list_item = 0;
                    }
                }
               
            }).finally(function() {
                $scope.is_loading = false;
               $state.go("cart-item-list", { value_id: $scope.value_id, cart:1 });
            });
        }
    });
    /*this function use for removing cart item from Opecart site*/
    $scope.removecartitem = function(product_id) {
        OpenCart.removecartitemfromcart(product_id).success(function(response) {
            $ionicLoading.hide();
            if(response.cart_details == true) {
                $scope.total_items =  OpenCart.opencart_local_item('opencart_counter');
                $scope.total_items--;
                OpenCart.set_opencart_local_item('opencart_counter', $scope.total_items)
                $state.go('cart-item-list', { value_id: $scope.value_id }, { reload: true });
            }
           
        });
    };
    /*this function use for removing cart item from local session*/
    $scope.removelocalcartitem = function(p_index) {
        OpenCart.removecartitemfromlocalcart(p_index).success(function(response) {
            if(response.cart_api_response_details.length > 0){
                $ionicLoading.hide();
                $scope.total_items =  OpenCart.opencart_local_item('opencart_counter');
                $scope.total_items--;
                OpenCart.set_opencart_local_item('opencart_counter', $scope.total_items);
            }else{
                $scope.total_items = 0;
                OpenCart.set_opencart_local_item('opencart_counter', $scope.total_items);
            }
            
            $state.go('cart-item-list', { value_id: $scope.value_id }, { reload: true });
        });
    };
}).controller('CheckoutAddressController', function($scope, $translate, $ionicLoading, $ionicModal,Customer,$rootScope,OpenCart,$state, $stateParams, $ionicSlideBoxDelegate, SafePopups) {
    $scope.contDirModal = {};
    $scope.page_title = $translate.instant("Address Book");
    $scope.is_loading = true;
    $scope.value_id = $stateParams.value_id;
    $scope.base_url = OpenCart.base_url;
    if(OpenCart.opencart_local_item('opencart_counter') >   0){
        $scope.total_items =  OpenCart.opencart_local_item('opencart_counter');
    }
    //get the user default addredd
    $scope.$on("$ionicView.beforeEnter", function(event, data){  
       
        if(OpenCart.opencart_local_item('opencart_user_session_id')){
            OpenCart.getopencartuseraddress().success(function(response) {
                $scope.homepage_dynamic_border_color = response.homepage_dynamic_border_color;
                $scope.is_loading = false;
                if(response.cart_details.success){
                    $scope.shipping_addess_found = 1;
                    $scope.address = response.cart_details.data.addresses;
                    $scope.address_id = OpenCart.address_id = response.cart_details.data.address_id;
                    $scope.zone_id = OpenCart.zone_id = response.cart_details.data.zone_id;
                    $scope.country_id = OpenCart.country_id = response.cart_details.data.country_id;
                    $scope.myadderssselect = {
                        range: $scope.address_id,
                    };
                }else{
                    $scope.shipping_addess_found = 0;
                    $scope.shipping_api_error_mgs = response.cart_details.error;
                }
                $state.go("checkout-address",{ value_id: $scope.value_id, order:1});
            });
        }else{
            
            //set and storage values which check user who click to continues on item list page has already product in list.
            OpenCart.set_opencart_local_item('is_have_cart_item_already_then', 1);
            $state.go("opencart-user-login",{ value_id: $scope.value_id, login:1});
        }
    });
    /*  new address model popup*/
    $scope.openAddressPopup = function() {
        $ionicModal.fromTemplateUrl('modules/opencart/templates/l1/address-update-model.html', {
            scope: $scope,
            animation: 'slide-in-up'
        }).then(function(modal) {
            $scope.contDirModal.search = modal;
            $scope.contDirModal.search.show();
        });
    };
    /*get countries  list*/
    $ionicLoading.show({content: 'Loading',animation: 'fade-in',showBackdrop: true,maxWidth: 200,showDelay: 0 });
    OpenCart.getcountries().success(function(response) {
        if(response.countries_list.success){
            $scope.countries = response.countries_list.data;
            $ionicLoading.hide();
        }
    });
    $scope.getcountryzones = function(country_id) {
        if(country_id){
            $ionicLoading.show({content: 'Loading',animation: 'fade-in',showBackdrop: true,maxWidth: 200,showDelay: 0 });
            OpenCart.getcountrydetails(country_id).success(function(response) {
                if(response.country_details.success){
                 $scope.country_zone_details = response.country_details.data.zone;
                   $ionicLoading.hide();
                }
            });
        }
    };
    /**
    * Remove all opened Contact Directory modals at once
    */
    $scope.closeModal = function() {
        if(angular.isObject($scope.contDirModal)) {
            for (var i in $scope.contDirModal) {
                if(angular.isObject($scope.contDirModal[i]) && angular.isFunction($scope.contDirModal[i].remove)) {
                    $scope.contDirModal[i].remove();
                }
            }
        }
    }
    $scope.addnewAddress = function(new_address_details) {
        if(new_address_details != undefined && new_address_details.firstname != undefined  && new_address_details.lastname != undefined   && new_address_details.address_1 != undefined  && new_address_details.city != undefined  && new_address_details.postcode != undefined && new_address_details.country != undefined && new_address_details.state != undefined ){
            $ionicLoading.show({content: 'Loading',animation: 'fade-in',showBackdrop: true,maxWidth: 200,showDelay: 0 });
            OpenCart.addnewaddresstoapi(new_address_details).success(function(response) {
            $ionicLoading.hide();
            $scope.closeModal();
            
            $state.go("delivery-methods",{ value_id: $scope.value_id, delivery_methods:1});
        });
        }else  if(new_address_details == undefined){
           $ionicPopup.alert({title: $translate.instant('Error'),template: $translate.instant("Please enter the form details."),buttons: [{ text: $translate.instant("OK") }]});
        }else if(new_address_details.firstname == undefined){
           $ionicPopup.alert({title: $translate.instant('Error'),template: $translate.instant("Your first name is required."),buttons: [{ text: $translate.instant("OK") }]});
        }else if(new_address_details.lastname == undefined){
           $ionicPopup.alert({title: $translate.instant('Error'),template: $translate.instant("Your last name is required."),buttons: [{ text: $translate.instant("OK") }]});
        } else if(new_address_details.address_1 == undefined){
            $ionicPopup.alert({title: $translate.instant('Error'),template: $translate.instant("Address 1 is required."),buttons: [{ text: $translate.instant("OK") }]});
        }else if(new_address_details.city == undefined){
           $ionicPopup.alert({title: $translate.instant('Error'),template: $translate.instant("City is required."),buttons: [{ text: $translate.instant("OK") }]});
        }else if(new_address_details.country == undefined){
            $ionicPopup.alert({title: $translate.instant('Error'),template: $translate.instant("Country is required."),buttons: [{ text: $translate.instant("OK") }]});
        }else if(new_address_details.state == undefined){
            $ionicPopup.alert({title: $translate.instant('Error'),template: $translate.instant("State is required."),buttons: [{ text: $translate.instant("OK") }]});
        } else if(new_address_details.postcode == undefined){
            $ionicPopup.alert({title: $translate.instant('Error'),template: $translate.instant("Post Code is required."),buttons: [{ text: $translate.instant("OK") }]});
        }else{
           $ionicPopup.alert({title: $translate.instant('Registration Failed'),template: $translate.instant("Registration Failed, Please try after sometime"),buttons: [{ text: $translate.instant("OK") }]});
        }
    };
    $scope.setpaymentaddress = function(set_address_id) {
        $scope.myadderssselect = {
            range: $scope.address_id,
        };
        $scope.address_id = OpenCart.address_id = set_address_id;
    };
    $scope.addtoprocess = function() {
        $state.go("checkout-address",{ value_id: $scope.value_id, order:1});
    };
    $scope.getPaymentMethods = function(address_id) {
        $state.go("payment-methods",{ value_id: $scope.value_id, payment:1});
        
    };
    $scope.getDeliveryMethods = function(address_id) {
        //$state.go("payment-methods",{ value_id: $scope.value_id, payment:1});
        $state.go("delivery-methods",{ value_id: $scope.value_id, delivery_methods:1});
    };
}).controller('DeliveryMethodsController', function($scope, $timeout,$translate, $ionicLoading, $ionicPopup,Customer,$rootScope,OpenCart,$state, $stateParams, $ionicSlideBoxDelegate, SafePopups) {
    $scope.page_title = $translate.instant("Delivery Methods");
    $scope.is_loading = false;
    $scope.base_url = OpenCart.base_url;
    $scope.value_id = $stateParams.value_id;
    $scope.address_id = OpenCart.address_id;
    OpenCart.set_opencart_local_item('address_id',OpenCart.address_id);
    $scope.base_url = OpenCart.base_url;
    $scope.develiverysselect = {
        range: 'weight' //defalut selection
    };
    
    if(OpenCart.opencart_local_item('opencart_counter') >   0){
        $scope.total_items =  OpenCart.opencart_local_item('opencart_counter');
    }
    //get the user default addredd
    $scope.$on("$ionicView.beforeEnter", function(event, data){  
        OpenCart.getopencartdeliverymethods().success(function(response) {
            $scope.delivery_methods_available = response.delivery_methods;
            
        });
    });
    $scope.getdeliveryoptioncode = function(delivery_method_code) {
        
        OpenCart.delivery_method_code = delivery_method_code;
        OpenCart.set_opencart_local_item('delivery_method_by',delivery_method_code);
        $state.go("payment-methods",{ value_id: $scope.value_id, payment:1});
        
    };
   
    // main image loaded ?
    //$('#payment_option_img').on('load', function(){
      $ionicLoading.show({content: 'Loading',animation: 'fade-in',showBackdrop: true,maxWidth: 200,showDelay: 0 });
       setTimeout(function() { $ionicLoading.hide(); }, 2000);
   // })
}).controller('PaymentMethodsController', function($scope, $timeout,$translate, $ionicLoading, $ionicPopup,Customer,$rootScope,OpenCart,$state, $stateParams, $ionicSlideBoxDelegate, SafePopups) {
    $scope.page_title = $translate.instant("Payment Methods");
    $scope.is_loading = false;
    $scope.base_url = OpenCart.base_url;
    $scope.value_id = $stateParams.value_id;
    $scope.delivery_method_code = OpenCart.delivery_method_code;
    $scope.address_id = OpenCart.address_id;
    OpenCart.set_opencart_local_item('address_id',OpenCart.address_id);
    OpenCart.set_opencart_local_item('delivery_method_code',OpenCart.delivery_method_code);
    $scope.base_url = OpenCart.base_url;
    $scope.myselect = {
        range: 'multibanco' //defalut selection
    };

    if(OpenCart.opencart_local_item('opencart_counter') >   0){
        $scope.total_items =  OpenCart.opencart_local_item('opencart_counter');
    }
    //get the user default addredd
    $scope.$on("$ionicView.beforeEnter", function(event, data){  
        OpenCart.getopencartpaymentmethods().success(function(response) {
            
            $scope.payment_methods = response.oc_response.data;
            if(response.oc_response.success){
                OpenCart.getappapidetails().success(function(paypalapiresponse){
                    if(paypalapiresponse.it_has_paypal){
                        $scope.paypal_option_enable = 1;
                       
                    }else{
                        $scope.paypal_option_enable = 0;
                    }
                    if(paypalapiresponse.deposit_or_transfer_bank !='error'){
                        $scope.deposit_or_transfer = 1;
                    }else{
                        $scope.deposit_or_transfer = 0;
                    }
                    if(paypalapiresponse.it_has_stripe){
                        $scope.is_stripe = 1;
                        $scope.stripe_val = 'stripe_payments';
                    }else{
                       $scope.is_stripe = 0;
                    }
                    $scope.is_loading = false;
                });

            }else{
                $ionicPopup.alert({title: $translate.instant('Error'),template: response.oc_response.error,buttons: [{ text: $translate.instant("OK") }]});
                $timeout(function() {
                     OpenCart.unset_opencart_local_item('opencart_counter');
                    $state.go("cart_view", { value_id: $scope.value_id });
            
                }, 500);

            }
        });
    });
    //change default payment process code after select to payment option
    $scope.getpaymentoptioncode = function(payment_code) {
        
        OpenCart.payment_by = payment_code;
        OpenCart.set_opencart_local_item('payment_by',payment_code);
        //payment by paypla standared
        
        if(payment_code == 'pp_standard'){
            // $scope.processPayment();
            $state.go("paypal-processed", { value_id: $scope.value_id, paypaloption:1 });
        }
        //payment by cash on delivery
        if(payment_code == 'cod'){
            //$state.go("cod-confirm", { value_id: $scope.value_id, cod_confirm:1 });
             $scope.processPayment();
        }
        //payment by multibanco 
        if(payment_code == 'multibanco'){
            $scope.processPayment();
        }
        //payment by Deposit or Wire Transfer
        if(payment_code == 'bank_transfer'){
            $state.go("deposit-or-transfer", { value_id: $scope.value_id, deposit__or_transfer:1 });
            // $state.go("order-total-processed", { value_id: $scope.value_id, order_total:1 });
           // $scope.processPayment();
        }
        if(payment_code == 'stripe_payments'){
            // $scope.processPayment();
            $state.go("opencart-sales-stripe", { value_id: $scope.value_id, stripe:1 });
        }
        
    };
    //process for payment 
    $scope.processPayment = function() {
        $ionicLoading.show({content: 'Loading',animation: 'fade-in',showBackdrop: true,maxWidth: 200,showDelay: 0 });
        OpenCart.processforpayment().success(function(response) {
            $ionicLoading.hide();
            if(response.oc_payment_response.success || response.oc_payment_response == 'multibanco'){
                if(response.oc_payment_response == 'multibanco'){
                   $state.go("order-multibanco-processed", { value_id: $scope.value_id, multibanco:1 });
                }
                 else{
                   
                    OpenCart.unset_opencart_local_item('opencart_counter');
                    $state.go("order-processed", { value_id: $scope.value_id, process:1 });
                }
            }else{
                $ionicPopup.alert({title: $translate.instant('Payment Failed'),template: $translate.instant("Payment Failed, Please try after sometime."),buttons: [{ text: $translate.instant("OK") }]});
            }
        });
    };
    $ionicLoading.show({content: 'Loading',animation: 'fade-in',showBackdrop: true,maxWidth: 200,showDelay: 0 });
    setTimeout(function() { $ionicLoading.hide(); }, 2000);
   
}).controller('OrderProcessedController', function($scope, $translate, $ionicLoading, $ionicPopup,Customer,$rootScope,OpenCart,$state, $stateParams, $ionicSlideBoxDelegate, SafePopups) {
    $scope.page_title = OpenCart.store_name;
    $scope.is_loading = true;
    $scope.value_id = $stateParams.value_id;
    $scope.base_url = OpenCart.base_url;
    $scope.$on('$ionicView.beforeEnter', function(event, viewData) {
        viewData.enableBack = false;
    });
    if(OpenCart.opencart_local_item('opencart_counter') >   0){
        $scope.total_items =  OpenCart.opencart_local_item('opencart_counter');
    }
    $scope.gotoaccount = function() {
        $state.go("opencart-customer-account", { value_id: $scope.value_id,customer:1 });
    };
}).controller('OrderProcessedWithPaypalController', function($scope,Application,$translate, $window, $location, $ionicLoading ,$ionicPopup,Customer,$rootScope,OpenCart,$state, $stateParams, $ionicSlideBoxDelegate, SafePopups) {
    /*This contorller use for adding dynamic form on the basis of cart data and send to paypal for payment and get response from paypal*/
    $scope.page_title =  OpenCart.store_name;
    $scope.is_loading = true;
    $scope.value_id = $stateParams.value_id;
    $scope.base_url = OpenCart.base_url;
    $scope.$on('$ionicView.beforeEnter', function(event, viewData) {
        viewData.enableBack = true;
    });
    OpenCart.session_cart_active = 0;
    if(OpenCart.opencart_local_item('opencart_counter') >   0){
        $scope.total_items =  OpenCart.opencart_local_item('opencart_counter');
    }
    var current_url = $location.url();
    $scope.cart_response_total = 0.00;
    $scope.base_url = OpenCart.base_url;
    $ionicLoading.show({content: 'Loading',animation: 'fade-in',showBackdrop: true,maxWidth: 200,showDelay: 0 });
    OpenCart.value_id = $stateParams.value_id;
    OpenCart.value_id = $stateParams.value_id;
    $scope.value_id = $stateParams.value_id;
    $scope.loadContent = function () {
        $scope.isDisabled = false;
        OpenCart.getapicartdata().success(function(response) {
            $scope.is_loading = false;
            if(response.cart_details.success){
                $scope.cart_response_data = response.cart_details.data.products;
            }else{
                $state.go("paypal-processed", { value_id: $scope.value_id, paypaloption:1 });
            }
        }).finally(function(){ 
             OpenCart.processforpayment().success(function(response) {
                    var full_response_str       = response.oc_payment_response.split("<tfoot>");
                    var total_pay_arr           = full_response_str[1].split("</tfoot>");
                    var total_pay_arr_pay       = total_pay_arr[0].split("<b>Total:</b></td>");
                    var total_pay_arr_pay_g       = total_pay_arr_pay[1].split("$");
                    if(total_pay_arr_pay_g == undefined){
                        var total_pay_arr_pay_g       = total_pay_arr_pay[1].split("€");
                        var total_pay_arr_payment_arr       = total_pay_arr_pay_g[1].split("</td>");
                        var total_amt = total_pay_arr_payment_arr[0]+'€';
                    }else{
                        $scope.current_currency_code_of_store = 'USD';
                        var total_pay_arr_payment_arr       = total_pay_arr_pay_g[1].split("</td>");
                        var total_amt = total_pay_arr_payment_arr[0];
                    }
                    $scope.cart_response_total = total_amt;
                }).finally(function(){
                      OpenCart.getappapidetails().success(function(paypalapiresponse){
                        if(paypalapiresponse.it_has_paypal){
                            $scope.cart_item_data                =  $scope.cart_response_data;
                            $scope.cart_item_total_data          =   $scope.cart_response_total;
                            $scope.current_currency_code_of_store =  $scope.current_currency_code_of_store;

                            $scope.current_url = $location.url();
                            if(Application.is_webview){
                                $scope.app_is_in_web = 1;
                            }else{
                                $scope.app_is_in_web = 0;
                            }
                            /*Get the total order*/
                            OpenCart.gepaypalpaymentrequest( $scope.cart_item_data,$scope.current_url,$scope.app_is_in_web,$scope.cart_item_total_data, $scope.current_currency_code_of_store ).success(function (data) {
                                if(data.token_url){
                                    $scope.onlinePaymentUrl = data.token_url;
                                    $scope.form_url = data.token_url;//data.form_url;
                                    $scope.right_button = {
                                        action: $scope.validate,
                                        label: $translate.instant("Confirm")
                                    };
                                    $ionicLoading.hide();
                                    $scope.is_loading = false;
                               }else{
                                    $ionicPopup.alert({title: $translate.instant('Error'),template: $translate.instant("Unable to take payment using PayPal."),buttons: [{ text: $translate.instant("OK") }]});
                                }
                            });
                        }else{
                            $ionicPopup.alert({title: $translate.instant('Error'),template: $translate.instant("Unable to take payment using PayPal."),buttons: [{ text: $translate.instant("OK") }]});
                        }

                    });

                });
          
        });
    };
    $scope.mytoken = '';
    $scope.myPayerId= '';
    $scope.validate = function () {
        $scope.isDisabled = true;
        $ionicLoading.show({content: 'Loading',animation: 'fade-in',showBackdrop: true,maxWidth: 200,showDelay: 0 });
        OpenCart.notes = $scope.notes || "";
        sessionStorage.setItem('mcommerce-notes',$scope.notes || "");
        if ($scope.onlinePaymentUrl) {
            if(Application.is_webview) {
                /*for website*/
                var browser = $window.location = $scope.onlinePaymentUrl;
            } else {
                /*for mobile*/
                var browser = $window.open($scope.onlinePaymentUrl, $rootScope.getTargetForLink(), 'location=yes');
                browser.addEventListener('loadstart', function(event) {
                var newurl = event.url.split('/?__goto__=');
                if(newurl[1] != undefined && $scope.mytoken !='' && $scope.myPayerId !='') {
                    $ionicLoading.hide();
                    
                    $state.go("opencart-sales-confirmation-payment", { value_id: $stateParams.value_id, confirm:1,token: $scope.mytoken, payerId: $scope.myPayerId });
                }else{
                        var res = newurl[0].concat(newurl[1]);
                        if(/(opencart\/mobile_view\/confirm)/.test(event.url)) {
                            var url = new URL(event.url);
                            var params = url.search.replace(/(^\?)/,'').split("&").map(function(n){return n = n.split("="),this[n[0]] = n[1],this}.bind({}))[0];
                            $scope.mytoken = params.token;
                            $scope.myPayerId= params.PayerID;
                            if($scope.mytoken !='' && $scope.myPayerId !='') {
                                browser.close();
                                
                                $state.go("opencart-sales-confirmation-payment", { value_id: $stateParams.value_id, confirm:1,token: $scope.mytoken, payerId: $scope.myPayerId });
                            }
                        } else if(/(opencart\/mobile_view\/cancel)/.test(event.url)) {
                            browser.close();
                            $ionicLoading.hide();
                            $state.go("opencart-sales-confirmation-cancel", {value_id: $stateParams.value_id, cancel: $stateParams.cancel});
            
                        }
                    }
                });

            }
        } else {
            $ionicPopup.alert({title: $translate.instant('Payment Failed'),template: $translate.instant("Payment Failed."),buttons: [{ text: $translate.instant("OK") }]});
        }
    };
 
    $scope.loadContent();
}).controller('OpencartSalesConfirmationConfirmPaymentController', function($scope,$translate, $ionicLoading, $ionicPopup,Customer,$rootScope,OpenCart,$state, $stateParams, $ionicSlideBoxDelegate,$window, $location, SafePopups) {
    $scope.page_title = OpenCart.store_name;
    $scope.is_loading = true;
    $scope.value_id = $stateParams.value_id;
    $scope.base_url = OpenCart.base_url;
    $scope.token = $stateParams.token;
    $scope.PayerID = $stateParams.payerId;
    $scope.base_url = OpenCart.base_url;
    $scope.delivery_method_code = OpenCart.opencart_local_item('delivery_method_by');
    OpenCart.delivery_method_code = OpenCart.opencart_local_item('delivery_method_by');
    
      
    if(OpenCart.opencart_local_item('opencart_counter') >   0){
        $scope.total_items =  OpenCart.opencart_local_item('opencart_counter');
    }
    
    /**Check paymet is success or pending**/
    if(OpenCart.opencart_local_item('opencart_user_session_id')){
        
        if($scope.token !='' && $scope.PayerID !=''){
            OpenCart.opencart_local_item('payment_by');
            OpenCart.opencart_local_item('address_id');
            OpenCart.paypalreturnurl().success(function(response) {
                $ionicLoading.hide();
                if(response.oc_payment_response.success){
                  OpenCart.unset_opencart_local_item('opencart_counter');
                  $state.go("order-processed", { value_id: $scope.value_id, process:1 });
                }else{
                    $ionicPopup.alert({title: $translate.instant('Payment Failed'),template: $translate.instant("Payment Failed, Please try after sometime."),buttons: [{ text: $translate.instant("OK") }]});
                    $state.go('cart_view', { value_id: $scope.value_id }, { reload: true });
                }
            });
        }   
    }else{
        $ionicPopup.alert({title: $translate.instant('Payment Failed'),template: $translate.instant("Payment Failed, Please try after sometime."),buttons: [{ text: $translate.instant("OK") }]});
        $state.go('cart_view', { value_id: $scope.value_id }, { reload: true });
    }

}).controller('OpencartWebSalesConfirmationCancelController', function($scope,$translate, $ionicLoading, $ionicPopup,Customer,$rootScope,OpenCart,$state, $stateParams, $ionicSlideBoxDelegate,$window,$location,SafePopups) {
    $scope.page_title = OpenCart.store_name;
    $scope.is_loading = true;
    $scope.value_id = $stateParams.value_id;
    $scope.base_url = OpenCart.base_url;
    $scope.base_url = OpenCart.base_url;
    if(OpenCart.opencart_local_item('opencart_counter') >   0){
        $scope.total_items =  OpenCart.opencart_local_item('opencart_counter');
    }
    $scope.delivery_method_code = OpenCart.opencart_local_item('delivery_method_by');
    OpenCart.delivery_method_code = OpenCart.opencart_local_item('delivery_method_by');


    var return_url = $location.url();
    /*code fot got token and id*/
    var paypal_return_url_arr = return_url.split("token=");
    var paypal_return_url_arr_for_token = paypal_return_url_arr[1].split("&PayerID=");
    var return_token = paypal_return_url_arr_for_token[0];
    var paypal_return_url_arr_for_payer_id = paypal_return_url_arr[1].split("&PayerID=");
    var return_payer_id = paypal_return_url_arr_for_payer_id[1];
    /**Check paymet is success or pending**/
    if(OpenCart.opencart_local_item('opencart_user_session_id')){
        if(return_token !='' && return_payer_id !=''){
            OpenCart.opencart_local_item('payment_by');
            OpenCart.opencart_local_item('address_id');
            OpenCart.paypalreturnurl().success(function(response) {
                $ionicLoading.hide();
                if(response.oc_payment_response.success){
                  OpenCart.unset_opencart_local_item('opencart_counter');
                  $state.go("order-processed", { value_id: $scope.value_id, process:1 });
                }else{
                    $ionicPopup.alert({title: $translate.instant('Payment Failed'),template: $translate.instant("Payment Failed, Please try after sometime."),buttons: [{ text: $translate.instant("OK") }]});
                    $state.go('cart_view', { value_id: $scope.value_id }, { reload: true });
                }
            });
        }   else {
            $ionicPopup.alert({title: $translate.instant('Payment Failed'),template: $translate.instant("Payment Failed, Please try after sometime."),buttons: [{ text: $translate.instant("OK") }]});
            $state.go('cart_view', { value_id: $scope.value_id }, { reload: true });
        }

    }else{
        $ionicPopup.alert({title: $translate.instant('Payment Failed'),template: $translate.instant("Payment Failed, Please try after sometime."),buttons: [{ text: $translate.instant("OK") }]});
        $state.go('cart_view', { value_id: $scope.value_id }, { reload: true });
    }

}).controller('OpencartSalesConfirmationCancelController', function($scope,$translate, $ionicLoading, $ionicPopup,Customer,$rootScope,OpenCart,$state, $stateParams, $ionicSlideBoxDelegate, SafePopups) {
    $scope.page_title = OpenCart.store_name;
    $scope.is_loading = true;
    $scope.value_id = $stateParams.value_id;
    $scope.base_url = OpenCart.base_url;
    $scope.token = $stateParams.token;
    $scope.PayerID = $stateParams.payerId;
    $scope.base_url = OpenCart.base_url;
    $ionicPopup.alert({title: $translate.instant('Payment Cancelled'),template: $translate.instant("Payment Cancelled, Please try after sometime."),buttons: [{ text: $translate.instant("OK") }]});
    $state.go('cart_view', { value_id: $scope.value_id }, { reload: true });

}).controller('OpencartSalesStripeViewController', function ($ionicLoading, $ionicPopup, $location, $scope, $state, $stateParams, $timeout, $translate, Application, Customer, OpenCart, SafePopups) {
    $scope.$on("connectionStateChange", function(event, args) {
        if(args.isOnline == true) {
            $scope.loadContent();
        }
    });
     $scope.$on('$ionicView.beforeEnter', function(event, viewData) {
        OpenCart.homepagedynamiccolor().success(function(dynamic_homepage) {
            $scope.homepage_dynamic_border_color = dynamic_homepage.homepage_dynamic_border_color;
            
        });
    });
    $scope.is_loading = true;
    $ionicLoading.show({
        template: "<ion-spinner class=\"spinner-custom\"></ion-spinner>"
    });
    $scope.value_id = OpenCart.value_id = $stateParams.value_id;
    $scope.card = {};
    $scope.payment = {};
    $scope.payment.save_card = false;
    $scope.payment.use_stored_card = false;
    $scope.delivery_method_code = OpenCart.opencart_local_item('delivery_method_by');
    OpenCart.delivery_method_code = OpenCart.opencart_local_item('delivery_method_by');
    $scope.loadContent = function () {
        
        $scope.guest_mode = Customer.guest_mode;
        if(Customer.isLoggedIn()) {
            var cust_id = Customer.id;
        } else {
            var cust_id = null;
        }
         
        //reset save card param
        $scope.payment.save_card = false;
        OpenCart.find(cust_id).success(function (data) {
            Stripe.setPublishableKey(data.publishable_key);
            $scope.cart_total = data.total;
            if(data.card && data.card.exp_year){
                $scope.card = data.card;
                $scope.payment.use_stored_card = true;
            }
        }).finally(function () {
            $scope.is_loading = false;
            $ionicLoading.hide();
        });

    };

    if(typeof Stripe == "undefined") {
        var stripeJS = document.createElement('script');
        stripeJS.type = "text/javascript";
        stripeJS.src = "https://js.stripe.com/v2/";
        stripeJS.onload = function() {
            $scope.loadContent();
        };
        document.body.appendChild(stripeJS);
    } else {
        $scope.loadContent();
    }

    $scope.unloadcard = function () {
        SafePopups.show("confirm",{
            title: $translate.instant('Confirmation'),
            template: $translate.instant("Do you confirm you want to remove your card?")
        }).then(function(res){
            if(res) {
                $scope.is_loading = true;
                $ionicLoading.show({
                    template: "<ion-spinner class=\"spinner-custom\"></ion-spinner>"
                });
                //we cannot be there without customer
                OpenCart.removeCard(Customer.id).success(function (data) {
                    $scope.oldcard = $scope.card;
                    $scope.card = {};
                    $scope.payment.use_stored_card = false;
                }).finally(function () {
                    $scope.is_loading = false;
                    $ionicLoading.hide();
                });
            }
        });
    };

    $scope.process = function () {
        if (!$scope.is_loading) {
            $scope.is_loading = true;
            $ionicLoading.show({
                template: "<ion-spinner class=\"spinner-custom\"></ion-spinner>"
            });
            if ($scope.payment.use_stored_card) {
                _process();
            } else {
                Stripe.card.createToken($scope.card, function (status, response) {
                    _stripeResponseHandler(status, response);
                });
            }
        }
    };

    var _stripeResponseHandler = function(status, response) {
        $timeout(function() {
            if (response.error) {
                $ionicPopup.show({
                    subTitle: response.error.message,
                    buttons: [{
                        text: $translate.instant("OK")
                    }]
                });
                $scope.is_loading = false;
                $ionicLoading.hide();
            } else {
                $scope.card = {
                    token: response.id,
                    last4: response.card.last4,
                    brand: response.card.brand,
                    exp_month: response.card.exp_month,
                    exp_year: response.card.exp_year,
                    exp: Math.round(+(new Date((new Date(response.card.exp_year, response.card.exp_month, 1)) - 1)) / 1000) | 0
                };

                _process();
            }
        });
    };

    //function to make payment when all is ready
    var _process = function () {
        var data = {
            "token": $scope.card.token,
            "use_stored_card": $scope.payment.use_stored_card,
            "save_card": $scope.payment.save_card,
            "customer_id": Customer.id || null
        };
         OpenCart.processforpayment().success(function(response) {
                    var full_response_str       = response.oc_payment_response.split("<tfoot>");
                    var total_pay_arr           = full_response_str[1].split("</tfoot>");
                    var total_pay_arr_pay       = total_pay_arr[0].split("<b>Total:</b></td>");
                    var total_pay_arr_pay_g       = total_pay_arr_pay[1].split("$");
                    if(total_pay_arr_pay_g == undefined){
                        var total_pay_arr_pay_g       = total_pay_arr_pay[1].split("€");
                        var total_pay_arr_payment_arr       = total_pay_arr_pay_g[1].split("</td>");
                        var total_amt = total_pay_arr_payment_arr[0]+'€';
                    }else{
                        var total_pay_arr_payment_arr       = total_pay_arr_pay_g[1].split("</td>");
                        var total_amt = total_pay_arr_payment_arr[0];
                    }
                    $scope.cart_response_total = total_amt;
                }).finally(function(){ 
                    payable_total_amount = $scope.cart_response_total;
                    OpenCart.process(data,payable_total_amount).success(function (res) {
                    if (res) {
                        $ionicLoading.show({content: 'Loading',animation: 'fade-in',showBackdrop: true,maxWidth: 200,showDelay: 0 });
                
                        OpenCart.processstripepayment().success(function (payment_esponse) {
                            if (payment_esponse) {
                                $ionicLoading.hide();
                                OpenCart.unset_opencart_local_item('opencart_counter');
                                $state.go("order-processed", { value_id: $scope.value_id, process:1 });
                            } else {
                                $ionicPopup.alert({title: $translate.instant('Error'),template: $translate.instant("Unexpected error"),buttons: [{ text: $translate.instant("OK") }]});
                                $state.go('cart_view', { value_id: $scope.value_id }, { reload: true });
                            }
                        });
                       
                    } else {
                       $ionicPopup.alert({title: $translate.instant('Error'),template: $translate.instant("Unexpected error"),buttons: [{ text: $translate.instant("OK") }]});
                               
                    }
                }).error(function (err) {
                    $ionicPopup.alert({title: $translate.instant('Error'),template: $translate.instant("Unexpected error"),buttons: [{ text: $translate.instant("OK") }]});
                               
                }).finally(function () {
                    $scope.is_loading = false;
                    $ionicLoading.hide();
                });

        });
        
    };

    $scope.right_button = {
        action: $scope.process,
        label: $translate.instant("Pay")
    };

}).controller('SearchProductsController', function($scope,$translate, $ionicLoading, $ionicPopup,Customer,$rootScope,OpenCart,$state, $stateParams, $ionicSlideBoxDelegate, SafePopups) {
    $scope.page_title = OpenCart.store_name;
    $scope.is_loading = true;
    $scope.value_id = $stateParams.value_id;
    $scope.base_url = OpenCart.base_url;
    if(OpenCart.opencart_local_item('opencart_counter') >   0){
        $scope.total_items =  OpenCart.opencart_local_item('opencart_counter');
    }
    //get all product into list
    $scope.$on("$ionicView.beforeEnter", function(event, data){
        OpenCart.getallsearchproducts().success(function(data) {
           $scope.products_lists = data.products;
        }).finally(function() {
            $scope.is_loading = false;
        });
    });
    $scope.opencartHome = function() {
        $state.go("cart_view",{ value_id: $scope.value_id});
    }
    /*get product details on the basis of product id from api*/
    $scope.productdetails = function(product_id) {
        $state.go("product-details",{ value_id: $scope.value_id, product_id:product_id });
    };
    $scope.login = function() {
        if(OpenCart.opencart_local_item('opencart_user_session_id')){
            OpenCart.getapicartdata().success(function(response) {
                if(response.cart_details=='error'){
                    $scope.list_item = 0;
                }else{
                    $scope.list_item = 1;
                    $scope.cart_response_data = response.cart_details.data.products;
                    $scope.cart_response_total = response.cart_details.data.totals;
                    OpenCart.set_opencart_local_item('opencart_counter',response.cart_item_counter);
                }
                $state.go("opencart-customer-account", { value_id: $scope.value_id, customer:1 });
            }).finally(function() {
                $scope.is_loading = false;
            });

        }else{
            $state.go("opencart-user-login",{ value_id: $scope.value_id, login:1});
        }
    };
}).controller('CustomerwishlistController', function($scope,$translate, $ionicLoading, $ionicPopup,Customer,$rootScope,OpenCart,$state, $stateParams, $ionicSlideBoxDelegate, SafePopups) {
    $scope.base_url = OpenCart.base_url;
    $scope.page_title = $translate.instant("Wish list");
    $scope.is_loading = true;
    if(OpenCart.opencart_local_item('opencart_counter') >   0){
        $scope.total_items =  OpenCart.opencart_local_item('opencart_counter');
    }
    $scope.value_id = $stateParams.value_id;
    $scope.$on("$ionicView.beforeEnter", function(event, data){
        $ionicLoading.show({content: 'Loading',animation: 'fade-in',showBackdrop: true,maxWidth: 200,showDelay: 0 });
        OpenCart.getallwhishlist().success(function(wishlistresponse) {
            $ionicLoading.hide();
            if(wishlistresponse.wishlist.success && wishlistresponse.wishlist.data.products.length > 0){
                $scope.wish_list_item = 1;
                $scope.wishlistproducts = wishlistresponse.wishlist.data.products;
            }else{
                $scope.wish_list_item = 0;
            }
        });
        //remove from wishlist
        $scope.removeFromWishlist = function(product_id) {
            $ionicLoading.show({content: 'Loading',animation: 'fade-in',showBackdrop: true,maxWidth: 200,showDelay: 0 });
            OpenCart.remove_wish_list_product_id = product_id;
            $scope.remove_wish_list_product_id = product_id;
            OpenCart.removewhishlistitem().success(function(wishlist_remove_response) {
                $ionicLoading.hide();
                if(wishlist_remove_response.update_wishlist_response.success){
                    $ionicPopup.alert({title: $translate.instant('Success'),template: $translate.instant(wishlist_remove_response.update_wishlist_response.data.success),buttons: [{ text: $translate.instant("OK") }]});
                }else{
                    $ionicPopup.alert({title: $translate.instant('Error'),template: $translate.instant("Unable to remove item from wish list, Please try after sometime"),buttons: [{ text: $translate.instant("OK") }]});
                }
                $state.go('customer-wishlist', { value_id: $scope.value_id, wishlist:1 }, { reload: true });
            });
        };
    });
    /*get product details on the basis of product id from api*/
    $scope.productdetails = function(product_id) {
        $state.go("product-details",{ value_id: $scope.value_id, product_id:product_id });
    };
}).controller('DepositOrTransferController', function($scope,$translate, $location, $ionicLoading, $ionicPopup,Customer,$rootScope,OpenCart,$state, $stateParams, $ionicSlideBoxDelegate, SafePopups) {
    $scope.page_title = $translate.instant("Deposit Or Transfer");
    if(OpenCart.opencart_local_item('opencart_counter') >   0){
        $scope.total_items =  OpenCart.opencart_local_item('opencart_counter');
    }
    $scope.is_loading = true;
    $scope.value_id = $stateParams.value_id;
    $scope.base_url = OpenCart.base_url;
    $ionicLoading.show({content: 'Loading',animation: 'fade-in',showBackdrop: true,maxWidth: 200,showDelay: 0 });
    OpenCart.getappapidetails().success(function(appapiresponse){
        if(appapiresponse.deposit_or_transfer_bank && appapiresponse.deposit_or_transfer_nib && appapiresponse.deposit_or_transfer_iban && appapiresponse.deposit_or_transfer_code_swift && appapiresponse.deposit_or_transfer_holder){
            $scope.deposit_or_transfer = 1;
            $scope.transfer_appapiresponse = appapiresponse;
        }else{
            $scope.deposit_or_transfer = 0;
        }
        
    }).finally(function() {
        $ionicLoading.hide();
        $scope.is_loading = false;
    });
    $scope.bankTransfer = function() {
        $ionicLoading.show({content: 'Loading',animation: 'fade-in',showBackdrop: true,maxWidth: 200,showDelay: 0 });
        OpenCart.processforpayment().success(function(response) {
            $ionicLoading.hide();
            if(response.oc_payment_response.success){
                 
                OpenCart.unset_opencart_local_item('opencart_counter');
                $state.go("order-processed", { value_id: $scope.value_id, process:1 });
            }else{
                $ionicPopup.alert({title: $translate.instant('Payment Failed'),template: $translate.instant("Payment Failed, Please try after sometime."),buttons: [{ text: $translate.instant("OK") }]});
            }
        });
    };
}).controller('OrdertTotalController', function($scope,$translate, $location, $ionicLoading, $ionicPopup,Customer,$rootScope,OpenCart,$state, $stateParams, $ionicSlideBoxDelegate, SafePopups) {
    $scope.page_title = $translate.instant("Multibanco");
    if(OpenCart.opencart_local_item('opencart_counter') >   0){
        $scope.total_items =  OpenCart.opencart_local_item('opencart_counter');
    }
    $scope.is_loading = true;
    $scope.value_id = $stateParams.value_id;
    $scope.base_url = OpenCart.base_url;
    /*get countries  list*/
    $ionicLoading.show({content: 'Loading',animation: 'fade-in',showBackdrop: true,maxWidth: 200,showDelay: 0 });
    //get multibanco details
    OpenCart.getmbdetails().success(function(response) {
        $ionicLoading.hide();
        $scope.mb_data = response.multibanco_details;
        var full_mb_response_str = response.multibanco_details.split("Entidade:");
        //for get entity
        var entity_brk_str  = full_mb_response_str[1].split('<td style=\"font-size: 14px; text-align:left\">');
        var entity_str      = entity_brk_str[1].split('<\/td>\r\n\t\t\t<\/tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td style=\"font-size: 14px; font-weight:bold; text-align:left\">');
        $scope.entity       = entity_str[0];
        //for get reference
        var reference_brk_str = full_mb_response_str[1].split('Refer&ecirc;ncia:<\/td>\r\n\t\t\t\t<td style=\"font-size: 14px; text-align:left\">');
        var reference_str     = reference_brk_str[1].split('<\/td>\r\n\t\t\t<\/tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td style=\"font-size: 14px; font-weight:bold; text-align:left\">');
        $scope.reference      = reference_str[0];
        //for get valur
        var valur_brk_str   = full_mb_response_str[1].split('Valor:<\/td>\r\n\t\t\t\t<td style=\"font-size: 14px; text-align:left\">');
        var valur_str       = valur_brk_str[1].split('<\/td>\r\n\t\t\t<\/tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td style=\"font-size:12px;border-top: 1px solid #0F65AB; border-left: 0px; border-right: 0px; border-bottom: 0px; background-color: #0F65AB; color: White; text-align:center;\" colspan=\"3\">');
        $scope.valur        = valur_str[0];
        
    });
   
    //confirming MB payment option for payment
    $scope.confirmMBPayment = function() {
        $ionicLoading.show({content: 'Loading',animation: 'fade-in',showBackdrop: true,maxWidth: 200,showDelay: 0 });
        OpenCart.confirmmbpayment().success(function(response) {
            $ionicLoading.hide();
            if(response.oc_payment_response.success){
                OpenCart.unset_opencart_local_item('opencart_counter');
                $state.go("order-processed", { value_id: $scope.value_id, process:1 });
            }else{
               $ionicPopup.alert({title: $translate.instant('Payment Failed'),template: $translate.instant("Payment Failed, Please try after sometime"),buttons: [{ text: $translate.instant("OK") }]});
            }
        });
    };
}).controller('MultibancoController', function($scope,$translate, $location, $ionicLoading, $ionicPopup,Customer,$rootScope,OpenCart,$state, $stateParams, $ionicSlideBoxDelegate, SafePopups) {
    $scope.page_title = $translate.instant("Multibanco");
    if(OpenCart.opencart_local_item('opencart_counter') >   0){
        $scope.total_items =  OpenCart.opencart_local_item('opencart_counter');
    }
    $scope.is_loading = true;
    $scope.value_id = $stateParams.value_id;
    $scope.base_url = OpenCart.base_url;
    /*get countries  list*/
    $ionicLoading.show({content: 'Loading',animation: 'fade-in',showBackdrop: true,maxWidth: 200,showDelay: 0 });
    //get multibanco details
    OpenCart.getmbdetails().success(function(response) {
        $ionicLoading.hide();
        $scope.mb_data = response.multibanco_details;
        var full_mb_response_str = response.multibanco_details.split("Entidade:");
        //for get entity
        var entity_brk_str  = full_mb_response_str[1].split('<td style=\"font-size: 14px; text-align:left\">');
        var entity_str      = entity_brk_str[1].split('<\/td>\r\n\t\t\t<\/tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td style=\"font-size: 14px; font-weight:bold; text-align:left\">');
        $scope.entity       = entity_str[0];
        //for get reference
        var reference_brk_str = full_mb_response_str[1].split('Refer&ecirc;ncia:<\/td>\r\n\t\t\t\t<td style=\"font-size: 14px; text-align:left\">');
        var reference_str     = reference_brk_str[1].split('<\/td>\r\n\t\t\t<\/tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td style=\"font-size: 14px; font-weight:bold; text-align:left\">');
        $scope.reference      = reference_str[0];
        //for get valur
        var valur_brk_str   = full_mb_response_str[1].split('Valor:<\/td>\r\n\t\t\t\t<td style=\"font-size: 14px; text-align:left\">');
        var valur_str       = valur_brk_str[1].split('<\/td>\r\n\t\t\t<\/tr>\r\n\t\t\t<tr>\r\n\t\t\t\t<td style=\"font-size:12px;border-top: 1px solid #0F65AB; border-left: 0px; border-right: 0px; border-bottom: 0px; background-color: #0F65AB; color: White; text-align:center;\" colspan=\"3\">');
        $scope.valur        = valur_str[0];
    });
    //confirming MB payment option for payment
    $scope.confirmMBPayment = function() {
        $ionicLoading.show({content: 'Loading',animation: 'fade-in',showBackdrop: true,maxWidth: 200,showDelay: 0 });
        OpenCart.confirmmbpayment().success(function(response) {
            $ionicLoading.hide();
            if(response.oc_payment_response.success){
                OpenCart.unset_opencart_local_item('opencart_counter');
                $state.go("order-processed", { value_id: $scope.value_id, process:1 });
            }else{
                $ionicPopup.alert({title: $translate.instant('Payment Failed'),template: $translate.instant("Payment Failed, Please try after sometime"),buttons: [{ text: $translate.instant("OK") }]});
            }
        });
    };
});
/*this directive use for number of product counter with button*/
App.directive('rnStepper', function() {
    return {
        restrict: 'AE',
        require: 'ngModel',
        scope: {
            min: '=',
            max: '=',
            ngModel: '=',
            ngDisabled: '='
        },
        template: '<div class="button-bar"><button type="button" style="border-radius: 4px;margin-top: 0px;margin-bottom: 20px;" class="button  button-small  button-custom" ng-disabled="isOverMin() || ngDisabled" ng-click="decrement()"><i class="icon ion-ios-minus-outline"></i></button>' +
                  '<input type="text" id="p_value_counter" style="width: 30%;text-align:center;"ng-model="ngModel" ng-disabled="ngDisabled">' +
                  '<button type="button" style="border-radius: 4px;margin-top: 0px;margin-bottom: 20px;" class="button  button-small  button-custom" ng-disabled="isOverMax() || ngDisabled" ng-click="increment()"><i class="icon ion-ios-plus-outline"></i></button> </div>',
        link: function(scope, iElement, iAttrs, ngModelController) {
            scope.label = '';
            if (angular.isDefined(iAttrs.label)) {
                iAttrs.$observe('label', function(value) {
                    scope.label = ' ' + value;
                    ngModelController.$render();
                });
            }
            ngModelController.$render = function() {
                // update the validation status
                checkValidity();
            };
            // when model change, cast to integer
            ngModelController.$formatters.push(function(value) {
                return parseInt(value, 10);
            });
            // when view change, cast to integer
            ngModelController.$parsers.push(function(value) {
                return parseInt(value, 10);
            });

            function checkValidity() {
                // check if min/max defined to check validity
                var valid = !(scope.isOverMin(true) || scope.isOverMax(true));
                ngModelController.$setValidity('outOfBounds', valid);
            }
            function updateModel(offset) {
                // update the model, call $parsers pipeline...
                ngModelController.$setViewValue(ngModelController.$viewValue + offset);
                // update the local view
                ngModelController.$render();
            }
            scope.isOverMin = function(strict) {
                var offset = strict?0:1;
                return (angular.isDefined(scope.min) && (ngModelController.$viewValue - offset) < parseInt(scope.min, 10));
            };
            scope.isOverMax = function(strict) {
                var offset = strict?0:1;
                return (angular.isDefined(scope.max) && (ngModelController.$viewValue + offset) > parseInt(scope.max, 10));
            };
            // update the value when user clicks the buttons
            scope.increment = function() {
                var inval = updateModel(+1);
                
            };
            scope.decrement = function() {
                 var deval = updateModel(-1);
               
            };
            // check validity on start, in case we're directly out of bounds
            checkValidity();
            // watch out min/max and recheck validity when they change
            scope.$watch('min+max', function() {
                checkValidity();
            });
        }
    };
});
/**filter for convert html of json encoded html lie &lt,&gt etc.**/
App.filter('trust', ['$sce', function($sce) {
    var div = document.createElement('div');
    return function(text) {
        div.innerHTML = text;
        return $sce.trustAsHtml(div.textContent);
    };
}]);

App.filter('trusted', ['$sce', function ($sce) {
   return $sce.trustAsResourceUrl;
}]);
App.directive('stringToTimestamp', function() {
    return {
        require: 'ngModel',
        link: function(scope, ele, attr, ngModel) {
            // view to model
            ngModel.$parsers.push(function(value) {
                return Date.parse(value);
            });
        }
    }
});
App.service('brandsService', function() {
  var dataList = [];

  var addData = function(newObj) {
      dataList.push(newObj);
  };

  var getData = function(){
      return dataList;
  };

  return {
    addData: addData,
    getData: getData
  };

});
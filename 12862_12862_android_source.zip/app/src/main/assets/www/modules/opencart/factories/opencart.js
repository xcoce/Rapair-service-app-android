App.factory('OpenCart', function($rootScope, $http, Url, $stateParams, AUTH_EVENTS, $window, $ocLazyLoad) {
    var factory = {};
    factory.value_id = null;
    factory.slider_brand_data = null;

    /** Loads jquery async */
    $ocLazyLoad.load([
        './js/modules/opencart/js/jquery-3.2.1.min.js'
    ]);

    /*=Local Storage==*/
    factory.opencart_local_item = function(key) {
		return $window.localStorage.getItem(key) || null;
	};
    factory.set_opencart_local_item = function(key,id) {
		$window.localStorage.setItem(key,id);
	};
    factory.unset_opencart_local_item = function(key) {
		$window.localStorage.removeItem(key);
	};
    //get store details
    factory.getstoredetails = function(){
        var params = {
            value_id: $stateParams.value_id
        };
        return $http({
            method: 'GET',
            url: Url.get("opencart/mobile_view/getstoredetails", params),
            cache: false,
            responseType:'json'
        });
    };
    factory.homepagedynamiccolor = function(){
        var params = {
            value_id: $stateParams.value_id
        };
        return $http({
            method: 'GET',
            url: Url.get("opencart/mobile_view/homepagedynamiccolor", params),
            cache: false,
            responseType:'json'
        });
    };
    
    //get banner slider
    factory.getbannerslider = function() {
       return $http({
            method: 'GET',
            url: Url.get("opencart/mobile_view/getbannerslider", { value_id: $stateParams.value_id }),
            cache: false,
            responseType: 'json'
        });
    };
    //get getcountries list
    factory.getcountries = function() {
        return $http({
            method: 'GET',
            url: Url.get("opencart/mobile_view/getcountrieslists", { value_id: $stateParams.value_id }),
            cache: false,
            responseType: 'json'
        });
    };
    //get the country details by id
    factory.getcountrydetails = function(country_id) {
        var params = {
            value_id: $stateParams.value_id,
            country_id: country_id
        };
        return $http({
            method: 'GET',
            url: Url.get("opencart/mobile_view/getcountrydetails", params),
            cache: false,
            responseType:'json'
        });
    };
    factory.getallproducts = function(page) {
        var params = {
            value_id: $stateParams.value_id,
            page: page
        };
        return $http({
            method: 'GET',
            url: Url.get("opencart/mobile_view/getwebservice", params),
            cache: false,
            responseType:'json'
        });
    };
    
    
    factory.getallbrands = function() {
        var params = {
            value_id: $stateParams.value_id,
        };
        return $http({
            method: 'GET',
            url: Url.get("opencart/mobile_view/getbrands", params),
            cache: false,
            responseType:'json'
        });
    };
    //get products by brand
    factory.brandproductlist = function(page) {
        var params = {
            value_id: $stateParams.value_id,
            manufacturer_id: $stateParams.manufacturer_id,
            page: page
        };
        return $http({
            method: 'GET',
            url: Url.get("opencart/mobile_view/brandproductlist", params),
            cache: false,
            responseType:'json'
        });
    };
    factory.getallsearchproducts = function(page) {
        var params = {
            value_id: $stateParams.value_id,
            page: page
        };
        return $http({
            method: 'GET',
            url: Url.get("opencart/mobile_view/getallsearchproducts", params),
            cache: false,
            responseType:'json'
        });
    };
    factory.getcategoryproduct = function(cpage, by_manufacturer_id){
        var params = {
            value_id: $stateParams.value_id,
            category_id:$stateParams.category_id,
            sub_category_id:$stateParams.sub_category_id,
            by_manufacturer_id: by_manufacturer_id,
            cpage: cpage
        };
        return $http({
            method: 'GET',
            url: Url.get("opencart/mobile_view/getproductbycategory", params),
            cache: false,
            responseType:'json'
        });
    };
    //get categories list
    factory.getcategories = function(){
        return $http({
            method: 'GET',
            url: Url.get("opencart/mobile_view/getcategories",{ value_id: $stateParams.value_id}),
            cache: false,
            responseType: 'json'
        });
    };
    factory.getcategoriesdepthlevel = function(sub_category_id){
        return $http({
            method: 'GET',
            url: Url.get("opencart/mobile_view/getcategoriesdepthlevel",{ value_id: $stateParams.value_id,  category_id:$stateParams.category_id, sub_category_id:$stateParams.sub_category_id}),
            cache: false,
            responseType: 'json'
        });
    };
    factory.subcategories = function(sub_category_id){
        return $http({
            method: 'GET',
            url: Url.get("opencart/mobile_view/subcategories",{ value_id: $stateParams.value_id,  category_id:sub_category_id}),
            cache: false,
            responseType: 'json'
        });
    };
    //get categories list
    factory.getproductdetails = function(){
        return $http({
            method: 'GET',
            url: Url.get("opencart/mobile_view/getproductdetails",{ value_id: $stateParams.value_id, product_id:$stateParams.product_id}),
            cache: false,
            responseType: 'json'
        });
    };
    //get getmanufacturer details
    factory.getmanufacturerdetails = function(manufacturer_id){
        return $http({
            method: 'GET',
            url: Url.get("opencart/mobile_view/getmanufacturerdetails",{ value_id: $stateParams.value_id, manufacturer_id:manufacturer_id}),
            cache: false,
            responseType: 'json'
        });
    };
    factory.getopencartuser = function(){
        return $http({
            method: 'GET',
            url: Url.get("opencart/mobile_view/getopencartuserdetails", { value_id: $stateParams.value_id, category_id:$stateParams.category_id }),
            cache: false,
            responseType: 'json'
        });
    };
    factory.getopencartapisessionid = function(){
        return $http({
            method: 'GET',
            url: Url.get("opencart/mobile_view/getapisessionid", { value_id: $stateParams.value_id }),
            cache: false,
            responseType: 'json'
        });
    };
    //login che check to api
    factory.opencartuserlogin = function(data) {
        data.value_id = this.value_id;
        var url = Url.get("opencart/mobile_view/opencartuserlogin");
        return $http.post(url, data);
    };
    //api registration
    factory.apiregistration = function(data) {
        data.value_id = $stateParams.value_id;
        var url = Url.get("opencart/mobile_view/apiregistration");
        return $http.post(url, data);
    };
    //post cart data to api
    factory.additemtocart = function(data) {
        data.value_id = this.value_id;
        data.quantity = this.p_quantity;
        data.opencart_user_session_id = this.opencart_local_item('opencart_user_session_id');
        var url = Url.get("opencart/mobile_view/addtocart");
        return $http.post(url, data);
    };
    factory.additemtolocalsessioncart = function(data) {
        //console.log('this p_quantity '+this.p_quantity);
        data.value_id = this.value_id;
        data.quantity = this.p_quantity;
        var url = Url.get("opencart/mobile_view/additemtolocalsessioncart");
        return $http.post(url, data);
    };
    factory.getitemtolocalsessioncart = function(){
        var params = {
            value_id: $stateParams.value_id
        };
        return $http({
            method: 'GET',
            url: Url.get("opencart/mobile_view/getitemtolocalsessioncart", params),
            cache: false,
            responseType:'json'
        });
    };
    factory.getapicartdata = function() {
        var data = {};
        data.value_id = this.value_id;
        data.opencart_user_session_id = this.opencart_local_item('opencart_user_session_id');
        var url = Url.get("opencart/mobile_view/getcartdata");
        return $http.post(url, data);
    };
    factory.removecartitemfromcart = function(product_id) {
        var data = {};
        data.product_id = product_id
        data.value_id = this.value_id;
        data.opencart_user_session_id = this.opencart_local_item('opencart_user_session_id');
        var url = Url.get("opencart/mobile_view/removecartitem");
        return $http.post(url, data);
    };
    factory.removecartitemfromlocalcart = function(p_index) {
        var data = {};
        data.p_index = p_index
        data.value_id = this.value_id;
        var url = Url.get("opencart/mobile_view/removecartitemfromlocalcart");
        return $http.post(url, data);
    };
    factory.getopencartuseraddress = function() {
        var data = {};
        data.value_id = this.value_id;
        data.opencart_user_session_id = this.opencart_local_item('opencart_user_session_id');
        var url = Url.get("opencart/mobile_view/getopencartuseraddress");
        return $http.post(url, data);
    };
    factory.getopencartpaymentmethods = function() {
        var data = {};
        data.address_id =  this.address_id;
        data.value_id = this.value_id;
        data.opencart_user_session_id = this.opencart_local_item('opencart_user_session_id');
        var url = Url.get("opencart/mobile_view/getocpaymentsmethods");
        return $http.post(url, data);
    };
    //function which are use for process payment after selecting payment option
    factory.processforpayment = function() {
        var data = {};
        data.payment_by = this.payment_by;
        data.delivery_method_code = this.delivery_method_code;
        data.address_id = this.address_id;
        data.value_id = this.value_id;
        data.opencart_user_session_id = this.opencart_local_item('opencart_user_session_id');
        var url = Url.get("opencart/mobile_view/processpayment");
        return $http.post(url, data);
    };
    factory.getopencartdeliverymethods = function() {
        var data = {};
        data.address_id = this.address_id;
        data.value_id = this.value_id;
        data.opencart_user_session_id = this.opencart_local_item('opencart_user_session_id');
        var url = Url.get("opencart/mobile_view/getopencartdeliverymethods");
        return $http.post(url, data);
    };
    
    //get all order for a customer 
    factory.getopencartuserorder = function(opencart_c_id) {
        var data = {};
        data.customer_id = opencart_c_id;//this.opencart_local_item('opencart_customer_id');
        data.value_id = this.value_id;
        data.opencart_user_session_id = this.opencart_local_item('opencart_user_session_id');
        var url = Url.get("opencart/mobile_view/getocorder");
        return $http.post(url, data);
    };
    //get all order for a customer 
    factory.getocorderdetails = function(order_id) {
       var data = {};
        data.order_id = order_id;
        data.value_id = this.value_id;
        data.opencart_user_session_id = this.opencart_local_item('opencart_user_session_id');
        var url = Url.get("opencart/mobile_view/getocorderdetails");
        return $http.post(url, data);
    };
    //get sorted products 
    factory.sortproductsbyfilter = function() {
       console.log(this.product_filter);
        var data = {};
        data.product_filter = this.product_filter;
        data.value_id = this.value_id;
        data.category_id = this.category_id;
        var url = Url.get("opencart/mobile_view/sortproducts");
        return $http.post(url, data);
    };
    //add to wishlist
    factory.addtowhishlist = function() {
        var data = {};
        data.value_id = this.value_id;
        data.whishlist_product_id = this.whishlist_product_id;
        data.opencart_user_session_id = this.opencart_local_item('opencart_user_session_id');
        var url = Url.get("opencart/mobile_view/addtowhishlist");
        return $http.post(url, data);
    };
    //get all wishlist
    factory.getallwhishlist = function() {
        var data = {};
        data.value_id = this.value_id;
        data.opencart_user_session_id = this.opencart_local_item('opencart_user_session_id');
        var url = Url.get("opencart/mobile_view/getallwhishlist");
        return $http.post(url, data);
    };
    //get all wishlist
    factory.getmbdetails = function() {
        var data = {};
        data.value_id = this.value_id;
        data.opencart_user_session_id = this.opencart_local_item('opencart_user_session_id');
        var url = Url.get("opencart/mobile_view/getmbdetails");
        return $http.post(url, data);
    };
    //remove item from wish list
    factory.removewhishlistitem = function() {
        var data = {};
        data.remove_wish_list_product_id = this.remove_wish_list_product_id;
        data.value_id = this.value_id;
        data.opencart_user_session_id = this.opencart_local_item('opencart_user_session_id');
        var url = Url.get("opencart/mobile_view/removefromwhishlist");
        return $http.post(url, data);
    };
    /*pay with paypal*/
    factory.paypalreturnurl = function() {
        var data = {};
        data.delivery_method_code = this.delivery_method_code;
        data.payment_by = this.opencart_local_item('payment_by');
        data.address_id = this.opencart_local_item('address_id');
        data.value_id = $stateParams.value_id;
        data.opencart_user_session_id = this.opencart_local_item('opencart_user_session_id');
        var url = Url.get("opencart/mobile_view/processpaypalpayment");
        return $http.post(url, data);
    };
    
    /*pay with stripe*/
    factory.processstripepayment = function() {
        var data = {};
        data.delivery_method_code = this.delivery_method_code;
        data.payment_by = this.opencart_local_item('payment_by');
        data.address_id = this.opencart_local_item('address_id');
        data.value_id = $stateParams.value_id;
        data.opencart_user_session_id = this.opencart_local_item('opencart_user_session_id');
        var url = Url.get("opencart/mobile_view/processstripepayment");
        return $http.post(url, data);
    };
    /*get api details*/
    factory.getappapidetails = function() {
        var data = {};
        data.value_id = $stateParams.value_id;
        data.opencart_user_session_id = this.opencart_local_item('opencart_user_session_id');
        var url = Url.get("opencart/mobile_view/getapidbdetails");
        return $http.post(url, data);
    };
     factory.gepaypalpaymentrequest = function(cart_item_data, current_url, app_is_in_web, cart_item_total_data,current_currency_code_of_store) {
        var data = {};
        data.value_id = $stateParams.value_id;
        data.cart_item_data = cart_item_data;
        data.cart_item_total_data = cart_item_total_data;
        data.current_currency_code_of_store = current_currency_code_of_store;
        data.current_app_url = current_url;
        data.app_is_in_web = app_is_in_web;
        data.opencart_user_session_id = this.opencart_local_item('opencart_user_session_id');
        var url = Url.get("opencart/mobile_view/gepaypalpaymentresponse");
        return $http.post(url, data);
    };
    //get information from api
    factory.getinformation = function() {
        var data = {};
        data.value_id = $stateParams.value_id;
        data.opencart_user_session_id = this.opencart_local_item('opencart_user_session_id');
        var url = Url.get("opencart/mobile_view/getinformation");
        return $http.post(url, data);
    };
    //post new address data to api
    factory.addnewaddresstoapi = function(data) {
        data.value_id = this.value_id;
        data.opencart_user_session_id = this.opencart_local_item('opencart_user_session_id');
        var url = Url.get("opencart/mobile_view/addnewaddress");
        return $http.post(url, data);
    };
    factory.postcomment = function(data) {
        data.value_id = this.value_id;
        data.product_id = $stateParams.product_id;
        data.myrating = this.myrating;
        var url = Url.get("opencart/mobile_view/postcomment");
        return $http.post(url, data);
    };
    //get the refine products
    factory.getrefineproduct = function(cpage, refine_request_data,category_url){
        var data = {};
        data.value_id        = $stateParams.value_id;
        data.category_id     = $stateParams.category_id;
        data.sub_category_id     = $stateParams.sub_category_id;
        data.brand_filter_id = refine_request_data.brand_name;
        data.color_filter_id = refine_request_data.p_color;
        data.price_filter_id = refine_request_data.p_price;
        data.category_url    = category_url;
        data.cpage           = cpage;
        var url = Url.get("opencart/mobile_view/getrefineproduct");
        return $http.post(url, data);
    };
    factory.searchqueiresrequest = function(query, search_page_numer){
        var data = {};
        data.value_id        = $stateParams.value_id;
        data.opencart_user_session_id = this.opencart_local_item('opencart_user_session_id');
        data.search_page_numer           = search_page_numer;
        data.query           = query;
        var url = Url.get("opencart/mobile_view/searchqueiresrequest");
        return $http.post(url, data);
    };
    //reset user api password 
    factory.resetuserapipassword = function(email) {
       //console.log('in factory');
        var data = {};
        data.email = email;
        data.value_id = this.value_id;
        data.opencart_user_session_id = this.opencart_local_item('opencart_user_session_id');
        var url = Url.get("opencart/mobile_view/forgottenpassword");
        return $http.post(url, data);
    };
    factory.logout = function() {
        return $http({
            method: 'GET',
            url: Url.get("customer/mobile_account_login/logout"),
            responseType:'json'
        }).success(function() {
            factory.clearCredentials();

            factory.can_access_locked_features = false;
            factory.id = null;
            factory.flushData();
        });
    };
    factory.confirmmbpayment = function() {
        var data = {};
        data.value_id = this.value_id;
        data.opencart_user_session_id = this.opencart_local_item('opencart_user_session_id');
        var url = Url.get("opencart/mobile_view/confirmbymultibanco");
        return $http.post(url, data);
    };
    factory.confirmpayment = function() {
        var data = {};
        data.value_id = this.value_id;
        data.opencart_user_session_id = this.opencart_local_item('opencart_user_session_id');
        var url = Url.get("opencart/mobile_view/confirmpayment");
        return $http.post(url, data);
    };
    
    //Get latest details of user from opencart API
    factory.getuserlatestdetailsfromapi = function() {
        var data = {};
        data.value_id = $stateParams.value_id;
        data.opencart_user_session_id = this.opencart_local_item('opencart_user_session_id');
        var url = Url.get("opencart/mobile_view/getuserlatestdetailsfromapi");
        return $http.post(url, data);
    };
    //Get total order details 
    factory.getconformationorderdetails = function() {
        var data = {};
        data.value_id = $stateParams.value_id;
        data.opencart_user_session_id = this.opencart_local_item('opencart_user_session_id');
        var url = Url.get("opencart/mobile_view/getconformationorderdetails");
        return $http.post(url, data);
    };
    factory.validateOnlinePayment = function (token, payerID) {

        if (!this.value_id) return;

        var url = Url.get("opencart/mobile_view/validatepayment", {
            value_id: this.value_id
        });

        var data = {
            token: token,
            PayerID: payerID,
            is_ajax: 1
        };

        return $sbhttp({
            method: 'POST',
            data: data,
            url: url,
            responseType:'json'
        });
    };
    factory.find = function(cust_id) {
        var params = {
            value_id: $stateParams.value_id,
            customer_id: cust_id,
            opencart_user_session_id : this.opencart_local_item('opencart_user_session_id'),
        };
        return $http({
            method: 'GET',
            url: Url.get("opencart/mobile_view/find", params),
            cache: false,
            responseType:'json'
        });
    };

    

    factory.process = function(data, payable_total_amount) {

        if(!this.value_id) return;

        return $http({
            method: 'POST',
            url: Url.get("opencart/mobile_view/process"),
            data: {
                value_id: this.value_id,
                token: data["token"],
                customer_id: data["customer_id"],
                use_stored_card: data["use_stored_card"],
                save_card: data["save_card"],
                notes: sessionStorage.getItem('mcommerce-notes') || "",
                opencart_user_session_id : this.opencart_local_item('opencart_user_session_id'),
                delivery_method_code:this.delivery_method_code,
                total_amout:payable_total_amount

            },
            cache: false,
            responseType:'json'
        });
    };

    factory.getCard = function(customer_id) {

        if(!this.value_id) return;

        return $http({
            method: 'POST',
            url: Url.get("opencart/mobile_view/getcard"),
            data: {"value_id": this.value_id, "customer_id": customer_id},
            cache: false,
            responseType:'json'
        });
    };

    factory.removeCard = function(customer_id) {

        if(!this.value_id) return;

        return $http({
            method: 'POST',
            url: Url.get("opencart/mobile_view/removecard"),
            data: {"value_id": this.value_id, "customer_id": customer_id},
            cache: false,
            responseType:'json'
        });
    };

    return factory;
});
App.factory('Authorization', function() {

    authorization = {};
    authorization.Name = "";
    authorization.Email = "";
    authorization.PhoneNo = "";
    authorization.customer_id = "";
    return authorization;
});